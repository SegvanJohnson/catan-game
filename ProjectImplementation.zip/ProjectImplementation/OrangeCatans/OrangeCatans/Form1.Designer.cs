﻿namespace OrangeCatans
{
    partial class Catan
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Catan));
            this.MapBox = new System.Windows.Forms.GroupBox();
            this.lbl6_1 = new System.Windows.Forms.Label();
            this.lbl14_9 = new System.Windows.Forms.Label();
            this.lbl10_9 = new System.Windows.Forms.Label();
            this.lbl6_9 = new System.Windows.Forms.Label();
            this.lbl16_7 = new System.Windows.Forms.Label();
            this.lbl12_7 = new System.Windows.Forms.Label();
            this.lbl8_7 = new System.Windows.Forms.Label();
            this.lbl4_7 = new System.Windows.Forms.Label();
            this.lbl18_5 = new System.Windows.Forms.Label();
            this.lbl14_5 = new System.Windows.Forms.Label();
            this.lbl10_5 = new System.Windows.Forms.Label();
            this.lbl6_5 = new System.Windows.Forms.Label();
            this.lbl2_5 = new System.Windows.Forms.Label();
            this.lbl16_3 = new System.Windows.Forms.Label();
            this.lbl12_3 = new System.Windows.Forms.Label();
            this.lbl8_3 = new System.Windows.Forms.Label();
            this.lbl4_3 = new System.Windows.Forms.Label();
            this.lbl14_1 = new System.Windows.Forms.Label();
            this.lbl10_1 = new System.Windows.Forms.Label();
            this.pbSettle0_4 = new System.Windows.Forms.PictureBox();
            this.pbSettle0_6 = new System.Windows.Forms.PictureBox();
            this.pbSettle14_10 = new System.Windows.Forms.PictureBox();
            this.pbSettle6_10 = new System.Windows.Forms.PictureBox();
            this.pbSettle10_10 = new System.Windows.Forms.PictureBox();
            this.pbSettle16_10 = new System.Windows.Forms.PictureBox();
            this.pbSettle12_10 = new System.Windows.Forms.PictureBox();
            this.pbSettle8_10 = new System.Windows.Forms.PictureBox();
            this.pbSettle4_10 = new System.Windows.Forms.PictureBox();
            this.pbSettle8_8 = new System.Windows.Forms.PictureBox();
            this.pbSettle12_8 = new System.Windows.Forms.PictureBox();
            this.pbSettle16_8 = new System.Windows.Forms.PictureBox();
            this.pbSettle18_8 = new System.Windows.Forms.PictureBox();
            this.pbSettle14_8 = new System.Windows.Forms.PictureBox();
            this.pbSettle10_8 = new System.Windows.Forms.PictureBox();
            this.pbSettle6_8 = new System.Windows.Forms.PictureBox();
            this.pbSettle2_8 = new System.Windows.Forms.PictureBox();
            this.pbSettle4_8 = new System.Windows.Forms.PictureBox();
            this.pbSettle20_6 = new System.Windows.Forms.PictureBox();
            this.pbSettle18_6 = new System.Windows.Forms.PictureBox();
            this.pbSettle16_6 = new System.Windows.Forms.PictureBox();
            this.pbSettle14_6 = new System.Windows.Forms.PictureBox();
            this.pbSettle12_6 = new System.Windows.Forms.PictureBox();
            this.pbSettle10_6 = new System.Windows.Forms.PictureBox();
            this.pbSettle8_6 = new System.Windows.Forms.PictureBox();
            this.pbSettle6_6 = new System.Windows.Forms.PictureBox();
            this.pbSettle2_6 = new System.Windows.Forms.PictureBox();
            this.pbSettle4_6 = new System.Windows.Forms.PictureBox();
            this.pbSettle20_4 = new System.Windows.Forms.PictureBox();
            this.pbSettle18_4 = new System.Windows.Forms.PictureBox();
            this.pbSettle16_4 = new System.Windows.Forms.PictureBox();
            this.pbSettle14_4 = new System.Windows.Forms.PictureBox();
            this.pbSettle12_4 = new System.Windows.Forms.PictureBox();
            this.pbSettle10_4 = new System.Windows.Forms.PictureBox();
            this.pbSettle4_4 = new System.Windows.Forms.PictureBox();
            this.pbSettle8_4 = new System.Windows.Forms.PictureBox();
            this.pbSettle6_4 = new System.Windows.Forms.PictureBox();
            this.pbSettle2_4 = new System.Windows.Forms.PictureBox();
            this.pbSettle2_2 = new System.Windows.Forms.PictureBox();
            this.pbSettle18_2 = new System.Windows.Forms.PictureBox();
            this.pbSettle12_2 = new System.Windows.Forms.PictureBox();
            this.pbSettle16_2 = new System.Windows.Forms.PictureBox();
            this.pbSettle14_2 = new System.Windows.Forms.PictureBox();
            this.pbSettle10_2 = new System.Windows.Forms.PictureBox();
            this.pbSettle8_2 = new System.Windows.Forms.PictureBox();
            this.pbSettle6_2 = new System.Windows.Forms.PictureBox();
            this.pbSettle4_2 = new System.Windows.Forms.PictureBox();
            this.pbSettle16_0 = new System.Windows.Forms.PictureBox();
            this.pbSettle12_0 = new System.Windows.Forms.PictureBox();
            this.pbSettle8_0 = new System.Windows.Forms.PictureBox();
            this.pbSettle4_0 = new System.Windows.Forms.PictureBox();
            this.pbSettle14_0 = new System.Windows.Forms.PictureBox();
            this.pbSettle10_0 = new System.Windows.Forms.PictureBox();
            this.pbSettle6_0 = new System.Windows.Forms.PictureBox();
            this.pbRoad11_6 = new System.Windows.Forms.PictureBox();
            this.pbRoad17_8 = new System.Windows.Forms.PictureBox();
            this.pbRoad15_10 = new System.Windows.Forms.PictureBox();
            this.pbRoad13_10 = new System.Windows.Forms.PictureBox();
            this.pbRoad11_10 = new System.Windows.Forms.PictureBox();
            this.pbRoad9_10 = new System.Windows.Forms.PictureBox();
            this.pbRoad7_10 = new System.Windows.Forms.PictureBox();
            this.pbRoad5_10 = new System.Windows.Forms.PictureBox();
            this.pbRoad16_9 = new System.Windows.Forms.PictureBox();
            this.pbRoad12_9 = new System.Windows.Forms.PictureBox();
            this.pbRoad8_9 = new System.Windows.Forms.PictureBox();
            this.pbRoad4_9 = new System.Windows.Forms.PictureBox();
            this.pbRoad15_8 = new System.Windows.Forms.PictureBox();
            this.pbRoad13_8 = new System.Windows.Forms.PictureBox();
            this.pbRoad11_8 = new System.Windows.Forms.PictureBox();
            this.pbRoad9_8 = new System.Windows.Forms.PictureBox();
            this.pbRoad7_8 = new System.Windows.Forms.PictureBox();
            this.pbRoad5_8 = new System.Windows.Forms.PictureBox();
            this.pbRoad18_7 = new System.Windows.Forms.PictureBox();
            this.pbRoad3_8 = new System.Windows.Forms.PictureBox();
            this.pbRoad10_7 = new System.Windows.Forms.PictureBox();
            this.pbRoad6_7 = new System.Windows.Forms.PictureBox();
            this.pbRoad2_7 = new System.Windows.Forms.PictureBox();
            this.pbRoad19_6 = new System.Windows.Forms.PictureBox();
            this.pbRoad17_6 = new System.Windows.Forms.PictureBox();
            this.pbRoad15_6 = new System.Windows.Forms.PictureBox();
            this.pbRoad13_6 = new System.Windows.Forms.PictureBox();
            this.pbRoad14_7 = new System.Windows.Forms.PictureBox();
            this.pbRoad19_4 = new System.Windows.Forms.PictureBox();
            this.pbRoad20_5 = new System.Windows.Forms.PictureBox();
            this.pbRoad16_5 = new System.Windows.Forms.PictureBox();
            this.pbRoad12_5 = new System.Windows.Forms.PictureBox();
            this.pbRoad9_6 = new System.Windows.Forms.PictureBox();
            this.pbRoad8_5 = new System.Windows.Forms.PictureBox();
            this.pbRoad7_6 = new System.Windows.Forms.PictureBox();
            this.pbRoad5_6 = new System.Windows.Forms.PictureBox();
            this.pbRoad3_6 = new System.Windows.Forms.PictureBox();
            this.pbRoad1_6 = new System.Windows.Forms.PictureBox();
            this.pbRoad4_5 = new System.Windows.Forms.PictureBox();
            this.pbRoad0_5 = new System.Windows.Forms.PictureBox();
            this.pbRoad1_4 = new System.Windows.Forms.PictureBox();
            this.pbRoad13_4 = new System.Windows.Forms.PictureBox();
            this.pbRoad15_4 = new System.Windows.Forms.PictureBox();
            this.pbRoad17_4 = new System.Windows.Forms.PictureBox();
            this.pbRoad17_2 = new System.Windows.Forms.PictureBox();
            this.pbRoad18_3 = new System.Windows.Forms.PictureBox();
            this.pbRoad14_3 = new System.Windows.Forms.PictureBox();
            this.pbRoad11_4 = new System.Windows.Forms.PictureBox();
            this.pbRoad7_4 = new System.Windows.Forms.PictureBox();
            this.pbRoad9_4 = new System.Windows.Forms.PictureBox();
            this.pbRoad10_3 = new System.Windows.Forms.PictureBox();
            this.pbRoad2_3 = new System.Windows.Forms.PictureBox();
            this.pbRoad3_4 = new System.Windows.Forms.PictureBox();
            this.pbRoad5_4 = new System.Windows.Forms.PictureBox();
            this.pbRoad6_3 = new System.Windows.Forms.PictureBox();
            this.pbRoad3_2 = new System.Windows.Forms.PictureBox();
            this.pbRoad13_0 = new System.Windows.Forms.PictureBox();
            this.pbRoad13_2 = new System.Windows.Forms.PictureBox();
            this.pbRoad15_2 = new System.Windows.Forms.PictureBox();
            this.pbRoad16_1 = new System.Windows.Forms.PictureBox();
            this.pbRoad15_0 = new System.Windows.Forms.PictureBox();
            this.pbRoad9_0 = new System.Windows.Forms.PictureBox();
            this.pbRoad9_2 = new System.Windows.Forms.PictureBox();
            this.pbRoad11_2 = new System.Windows.Forms.PictureBox();
            this.pbRoad12_1 = new System.Windows.Forms.PictureBox();
            this.pbRoad11_0 = new System.Windows.Forms.PictureBox();
            this.pbRoad5_0 = new System.Windows.Forms.PictureBox();
            this.pbRoad4_1 = new System.Windows.Forms.PictureBox();
            this.pbRoad5_2 = new System.Windows.Forms.PictureBox();
            this.pbRoad7_2 = new System.Windows.Forms.PictureBox();
            this.pbRoad8_1 = new System.Windows.Forms.PictureBox();
            this.pbLandTile14_9 = new System.Windows.Forms.PictureBox();
            this.pbRoad7_0 = new System.Windows.Forms.PictureBox();
            this.pbLandTile10_9 = new System.Windows.Forms.PictureBox();
            this.pbLandTile16_7 = new System.Windows.Forms.PictureBox();
            this.pbLandTile12_7 = new System.Windows.Forms.PictureBox();
            this.pbLandTile18_5 = new System.Windows.Forms.PictureBox();
            this.pbLandTile14_5 = new System.Windows.Forms.PictureBox();
            this.pbLandTile16_3 = new System.Windows.Forms.PictureBox();
            this.pbLandTile6_9 = new System.Windows.Forms.PictureBox();
            this.pbLandTile8_7 = new System.Windows.Forms.PictureBox();
            this.pbLandTile4_7 = new System.Windows.Forms.PictureBox();
            this.pbLandTile10_5 = new System.Windows.Forms.PictureBox();
            this.pbLandTile2_5 = new System.Windows.Forms.PictureBox();
            this.pbLandTile6_5 = new System.Windows.Forms.PictureBox();
            this.pbLandTile12_3 = new System.Windows.Forms.PictureBox();
            this.pbLandTile8_3 = new System.Windows.Forms.PictureBox();
            this.pbLandTile4_3 = new System.Windows.Forms.PictureBox();
            this.pbLandTile14_1 = new System.Windows.Forms.PictureBox();
            this.pbLandTile10_1 = new System.Windows.Forms.PictureBox();
            this.pbLandTile6_1 = new System.Windows.Forms.PictureBox();
            this.GameControls = new System.Windows.Forms.GroupBox();
            this.btnHand = new System.Windows.Forms.Button();
            this.btnEndTurn = new System.Windows.Forms.Button();
            this.btnUpgrade = new System.Windows.Forms.Button();
            this.btnBuyCard = new System.Windows.Forms.Button();
            this.btnBuild = new System.Windows.Forms.Button();
            this.btnTrade = new System.Windows.Forms.Button();
            this.btnRoll = new System.Windows.Forms.Button();
            this.flowLayoutPanel1 = new System.Windows.Forms.FlowLayoutPanel();
            this.btnPlayer1 = new System.Windows.Forms.Button();
            this.btnPlayer2 = new System.Windows.Forms.Button();
            this.btnPlayer3 = new System.Windows.Forms.Button();
            this.btnPlayer4 = new System.Windows.Forms.Button();
            this.tbOutputBox = new System.Windows.Forms.TextBox();
            this.tbPlayerStringInput = new System.Windows.Forms.TextBox();
            this.btnNewGame = new System.Windows.Forms.Button();
            this.MapBox.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbSettle0_4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbSettle0_6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbSettle14_10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbSettle6_10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbSettle10_10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbSettle16_10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbSettle12_10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbSettle8_10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbSettle4_10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbSettle8_8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbSettle12_8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbSettle16_8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbSettle18_8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbSettle14_8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbSettle10_8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbSettle6_8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbSettle2_8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbSettle4_8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbSettle20_6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbSettle18_6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbSettle16_6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbSettle14_6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbSettle12_6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbSettle10_6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbSettle8_6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbSettle6_6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbSettle2_6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbSettle4_6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbSettle20_4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbSettle18_4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbSettle16_4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbSettle14_4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbSettle12_4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbSettle10_4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbSettle4_4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbSettle8_4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbSettle6_4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbSettle2_4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbSettle2_2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbSettle18_2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbSettle12_2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbSettle16_2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbSettle14_2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbSettle10_2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbSettle8_2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbSettle6_2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbSettle4_2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbSettle16_0)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbSettle12_0)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbSettle8_0)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbSettle4_0)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbSettle14_0)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbSettle10_0)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbSettle6_0)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbRoad11_6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbRoad17_8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbRoad15_10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbRoad13_10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbRoad11_10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbRoad9_10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbRoad7_10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbRoad5_10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbRoad16_9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbRoad12_9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbRoad8_9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbRoad4_9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbRoad15_8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbRoad13_8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbRoad11_8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbRoad9_8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbRoad7_8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbRoad5_8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbRoad18_7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbRoad3_8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbRoad10_7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbRoad6_7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbRoad2_7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbRoad19_6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbRoad17_6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbRoad15_6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbRoad13_6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbRoad14_7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbRoad19_4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbRoad20_5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbRoad16_5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbRoad12_5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbRoad9_6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbRoad8_5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbRoad7_6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbRoad5_6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbRoad3_6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbRoad1_6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbRoad4_5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbRoad0_5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbRoad1_4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbRoad13_4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbRoad15_4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbRoad17_4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbRoad17_2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbRoad18_3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbRoad14_3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbRoad11_4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbRoad7_4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbRoad9_4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbRoad10_3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbRoad2_3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbRoad3_4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbRoad5_4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbRoad6_3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbRoad3_2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbRoad13_0)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbRoad13_2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbRoad15_2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbRoad16_1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbRoad15_0)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbRoad9_0)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbRoad9_2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbRoad11_2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbRoad12_1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbRoad11_0)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbRoad5_0)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbRoad4_1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbRoad5_2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbRoad7_2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbRoad8_1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbLandTile14_9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbRoad7_0)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbLandTile10_9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbLandTile16_7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbLandTile12_7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbLandTile18_5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbLandTile14_5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbLandTile16_3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbLandTile6_9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbLandTile8_7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbLandTile4_7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbLandTile10_5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbLandTile2_5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbLandTile6_5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbLandTile12_3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbLandTile8_3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbLandTile4_3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbLandTile14_1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbLandTile10_1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbLandTile6_1)).BeginInit();
            this.GameControls.SuspendLayout();
            this.flowLayoutPanel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // MapBox
            // 
            this.MapBox.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.MapBox.BackColor = System.Drawing.Color.Transparent;
            this.MapBox.Controls.Add(this.lbl6_1);
            this.MapBox.Controls.Add(this.lbl14_9);
            this.MapBox.Controls.Add(this.lbl10_9);
            this.MapBox.Controls.Add(this.lbl6_9);
            this.MapBox.Controls.Add(this.lbl16_7);
            this.MapBox.Controls.Add(this.lbl12_7);
            this.MapBox.Controls.Add(this.lbl8_7);
            this.MapBox.Controls.Add(this.lbl4_7);
            this.MapBox.Controls.Add(this.lbl18_5);
            this.MapBox.Controls.Add(this.lbl14_5);
            this.MapBox.Controls.Add(this.lbl10_5);
            this.MapBox.Controls.Add(this.lbl6_5);
            this.MapBox.Controls.Add(this.lbl2_5);
            this.MapBox.Controls.Add(this.lbl16_3);
            this.MapBox.Controls.Add(this.lbl12_3);
            this.MapBox.Controls.Add(this.lbl8_3);
            this.MapBox.Controls.Add(this.lbl4_3);
            this.MapBox.Controls.Add(this.lbl14_1);
            this.MapBox.Controls.Add(this.lbl10_1);
            this.MapBox.Controls.Add(this.pbSettle0_4);
            this.MapBox.Controls.Add(this.pbSettle0_6);
            this.MapBox.Controls.Add(this.pbSettle14_10);
            this.MapBox.Controls.Add(this.pbSettle6_10);
            this.MapBox.Controls.Add(this.pbSettle10_10);
            this.MapBox.Controls.Add(this.pbSettle16_10);
            this.MapBox.Controls.Add(this.pbSettle12_10);
            this.MapBox.Controls.Add(this.pbSettle8_10);
            this.MapBox.Controls.Add(this.pbSettle4_10);
            this.MapBox.Controls.Add(this.pbSettle8_8);
            this.MapBox.Controls.Add(this.pbSettle12_8);
            this.MapBox.Controls.Add(this.pbSettle16_8);
            this.MapBox.Controls.Add(this.pbSettle18_8);
            this.MapBox.Controls.Add(this.pbSettle14_8);
            this.MapBox.Controls.Add(this.pbSettle10_8);
            this.MapBox.Controls.Add(this.pbSettle6_8);
            this.MapBox.Controls.Add(this.pbSettle2_8);
            this.MapBox.Controls.Add(this.pbSettle4_8);
            this.MapBox.Controls.Add(this.pbSettle20_6);
            this.MapBox.Controls.Add(this.pbSettle18_6);
            this.MapBox.Controls.Add(this.pbSettle16_6);
            this.MapBox.Controls.Add(this.pbSettle14_6);
            this.MapBox.Controls.Add(this.pbSettle12_6);
            this.MapBox.Controls.Add(this.pbSettle10_6);
            this.MapBox.Controls.Add(this.pbSettle8_6);
            this.MapBox.Controls.Add(this.pbSettle6_6);
            this.MapBox.Controls.Add(this.pbSettle2_6);
            this.MapBox.Controls.Add(this.pbSettle4_6);
            this.MapBox.Controls.Add(this.pbSettle20_4);
            this.MapBox.Controls.Add(this.pbSettle18_4);
            this.MapBox.Controls.Add(this.pbSettle16_4);
            this.MapBox.Controls.Add(this.pbSettle14_4);
            this.MapBox.Controls.Add(this.pbSettle12_4);
            this.MapBox.Controls.Add(this.pbSettle10_4);
            this.MapBox.Controls.Add(this.pbSettle4_4);
            this.MapBox.Controls.Add(this.pbSettle8_4);
            this.MapBox.Controls.Add(this.pbSettle6_4);
            this.MapBox.Controls.Add(this.pbSettle2_4);
            this.MapBox.Controls.Add(this.pbSettle2_2);
            this.MapBox.Controls.Add(this.pbSettle18_2);
            this.MapBox.Controls.Add(this.pbSettle12_2);
            this.MapBox.Controls.Add(this.pbSettle16_2);
            this.MapBox.Controls.Add(this.pbSettle14_2);
            this.MapBox.Controls.Add(this.pbSettle10_2);
            this.MapBox.Controls.Add(this.pbSettle8_2);
            this.MapBox.Controls.Add(this.pbSettle6_2);
            this.MapBox.Controls.Add(this.pbSettle4_2);
            this.MapBox.Controls.Add(this.pbSettle16_0);
            this.MapBox.Controls.Add(this.pbSettle12_0);
            this.MapBox.Controls.Add(this.pbSettle8_0);
            this.MapBox.Controls.Add(this.pbSettle4_0);
            this.MapBox.Controls.Add(this.pbSettle14_0);
            this.MapBox.Controls.Add(this.pbSettle10_0);
            this.MapBox.Controls.Add(this.pbSettle6_0);
            this.MapBox.Controls.Add(this.pbRoad11_6);
            this.MapBox.Controls.Add(this.pbRoad17_8);
            this.MapBox.Controls.Add(this.pbRoad15_10);
            this.MapBox.Controls.Add(this.pbRoad13_10);
            this.MapBox.Controls.Add(this.pbRoad11_10);
            this.MapBox.Controls.Add(this.pbRoad9_10);
            this.MapBox.Controls.Add(this.pbRoad7_10);
            this.MapBox.Controls.Add(this.pbRoad5_10);
            this.MapBox.Controls.Add(this.pbRoad16_9);
            this.MapBox.Controls.Add(this.pbRoad12_9);
            this.MapBox.Controls.Add(this.pbRoad8_9);
            this.MapBox.Controls.Add(this.pbRoad4_9);
            this.MapBox.Controls.Add(this.pbRoad15_8);
            this.MapBox.Controls.Add(this.pbRoad13_8);
            this.MapBox.Controls.Add(this.pbRoad11_8);
            this.MapBox.Controls.Add(this.pbRoad9_8);
            this.MapBox.Controls.Add(this.pbRoad7_8);
            this.MapBox.Controls.Add(this.pbRoad5_8);
            this.MapBox.Controls.Add(this.pbRoad18_7);
            this.MapBox.Controls.Add(this.pbRoad3_8);
            this.MapBox.Controls.Add(this.pbRoad10_7);
            this.MapBox.Controls.Add(this.pbRoad6_7);
            this.MapBox.Controls.Add(this.pbRoad2_7);
            this.MapBox.Controls.Add(this.pbRoad19_6);
            this.MapBox.Controls.Add(this.pbRoad17_6);
            this.MapBox.Controls.Add(this.pbRoad15_6);
            this.MapBox.Controls.Add(this.pbRoad13_6);
            this.MapBox.Controls.Add(this.pbRoad14_7);
            this.MapBox.Controls.Add(this.pbRoad19_4);
            this.MapBox.Controls.Add(this.pbRoad20_5);
            this.MapBox.Controls.Add(this.pbRoad16_5);
            this.MapBox.Controls.Add(this.pbRoad12_5);
            this.MapBox.Controls.Add(this.pbRoad9_6);
            this.MapBox.Controls.Add(this.pbRoad8_5);
            this.MapBox.Controls.Add(this.pbRoad7_6);
            this.MapBox.Controls.Add(this.pbRoad5_6);
            this.MapBox.Controls.Add(this.pbRoad3_6);
            this.MapBox.Controls.Add(this.pbRoad1_6);
            this.MapBox.Controls.Add(this.pbRoad4_5);
            this.MapBox.Controls.Add(this.pbRoad0_5);
            this.MapBox.Controls.Add(this.pbRoad1_4);
            this.MapBox.Controls.Add(this.pbRoad13_4);
            this.MapBox.Controls.Add(this.pbRoad15_4);
            this.MapBox.Controls.Add(this.pbRoad17_4);
            this.MapBox.Controls.Add(this.pbRoad17_2);
            this.MapBox.Controls.Add(this.pbRoad18_3);
            this.MapBox.Controls.Add(this.pbRoad14_3);
            this.MapBox.Controls.Add(this.pbRoad11_4);
            this.MapBox.Controls.Add(this.pbRoad7_4);
            this.MapBox.Controls.Add(this.pbRoad9_4);
            this.MapBox.Controls.Add(this.pbRoad10_3);
            this.MapBox.Controls.Add(this.pbRoad2_3);
            this.MapBox.Controls.Add(this.pbRoad3_4);
            this.MapBox.Controls.Add(this.pbRoad5_4);
            this.MapBox.Controls.Add(this.pbRoad6_3);
            this.MapBox.Controls.Add(this.pbRoad3_2);
            this.MapBox.Controls.Add(this.pbRoad13_0);
            this.MapBox.Controls.Add(this.pbRoad13_2);
            this.MapBox.Controls.Add(this.pbRoad15_2);
            this.MapBox.Controls.Add(this.pbRoad16_1);
            this.MapBox.Controls.Add(this.pbRoad15_0);
            this.MapBox.Controls.Add(this.pbRoad9_0);
            this.MapBox.Controls.Add(this.pbRoad9_2);
            this.MapBox.Controls.Add(this.pbRoad11_2);
            this.MapBox.Controls.Add(this.pbRoad12_1);
            this.MapBox.Controls.Add(this.pbRoad11_0);
            this.MapBox.Controls.Add(this.pbRoad5_0);
            this.MapBox.Controls.Add(this.pbRoad4_1);
            this.MapBox.Controls.Add(this.pbRoad5_2);
            this.MapBox.Controls.Add(this.pbRoad7_2);
            this.MapBox.Controls.Add(this.pbRoad8_1);
            this.MapBox.Controls.Add(this.pbLandTile14_9);
            this.MapBox.Controls.Add(this.pbRoad7_0);
            this.MapBox.Controls.Add(this.pbLandTile10_9);
            this.MapBox.Controls.Add(this.pbLandTile16_7);
            this.MapBox.Controls.Add(this.pbLandTile12_7);
            this.MapBox.Controls.Add(this.pbLandTile18_5);
            this.MapBox.Controls.Add(this.pbLandTile14_5);
            this.MapBox.Controls.Add(this.pbLandTile16_3);
            this.MapBox.Controls.Add(this.pbLandTile6_9);
            this.MapBox.Controls.Add(this.pbLandTile8_7);
            this.MapBox.Controls.Add(this.pbLandTile4_7);
            this.MapBox.Controls.Add(this.pbLandTile10_5);
            this.MapBox.Controls.Add(this.pbLandTile2_5);
            this.MapBox.Controls.Add(this.pbLandTile6_5);
            this.MapBox.Controls.Add(this.pbLandTile12_3);
            this.MapBox.Controls.Add(this.pbLandTile8_3);
            this.MapBox.Controls.Add(this.pbLandTile4_3);
            this.MapBox.Controls.Add(this.pbLandTile14_1);
            this.MapBox.Controls.Add(this.pbLandTile10_1);
            this.MapBox.Controls.Add(this.pbLandTile6_1);
            this.MapBox.Location = new System.Drawing.Point(12, 3);
            this.MapBox.Name = "MapBox";
            this.MapBox.Size = new System.Drawing.Size(788, 731);
            this.MapBox.TabIndex = 1;
            this.MapBox.TabStop = false;
            this.MapBox.Text = "Map";
            // 
            // lbl6_1
            // 
            this.lbl6_1.AutoSize = true;
            this.lbl6_1.Location = new System.Drawing.Point(221, 89);
            this.lbl6_1.Name = "lbl6_1";
            this.lbl6_1.Size = new System.Drawing.Size(33, 13);
            this.lbl6_1.TabIndex = 166;
            this.lbl6_1.Text = "blank";
            // 
            // lbl14_9
            // 
            this.lbl14_9.AutoSize = true;
            this.lbl14_9.Location = new System.Drawing.Point(535, 626);
            this.lbl14_9.Name = "lbl14_9";
            this.lbl14_9.Size = new System.Drawing.Size(33, 13);
            this.lbl14_9.TabIndex = 165;
            this.lbl14_9.Text = "blank";
            // 
            // lbl10_9
            // 
            this.lbl10_9.AutoSize = true;
            this.lbl10_9.Location = new System.Drawing.Point(376, 626);
            this.lbl10_9.Name = "lbl10_9";
            this.lbl10_9.Size = new System.Drawing.Size(33, 13);
            this.lbl10_9.TabIndex = 164;
            this.lbl10_9.Text = "blank";
            // 
            // lbl6_9
            // 
            this.lbl6_9.AutoSize = true;
            this.lbl6_9.Location = new System.Drawing.Point(221, 626);
            this.lbl6_9.Name = "lbl6_9";
            this.lbl6_9.Size = new System.Drawing.Size(33, 13);
            this.lbl6_9.TabIndex = 163;
            this.lbl6_9.Text = "blank";
            // 
            // lbl16_7
            // 
            this.lbl16_7.AutoSize = true;
            this.lbl16_7.Location = new System.Drawing.Point(611, 489);
            this.lbl16_7.Name = "lbl16_7";
            this.lbl16_7.Size = new System.Drawing.Size(33, 13);
            this.lbl16_7.TabIndex = 162;
            this.lbl16_7.Text = "blank";
            // 
            // lbl12_7
            // 
            this.lbl12_7.AutoSize = true;
            this.lbl12_7.Location = new System.Drawing.Point(455, 489);
            this.lbl12_7.Name = "lbl12_7";
            this.lbl12_7.Size = new System.Drawing.Size(33, 13);
            this.lbl12_7.TabIndex = 161;
            this.lbl12_7.Text = "blank";
            // 
            // lbl8_7
            // 
            this.lbl8_7.AutoSize = true;
            this.lbl8_7.Location = new System.Drawing.Point(299, 489);
            this.lbl8_7.Name = "lbl8_7";
            this.lbl8_7.Size = new System.Drawing.Size(33, 13);
            this.lbl8_7.TabIndex = 160;
            this.lbl8_7.Text = "blank";
            // 
            // lbl4_7
            // 
            this.lbl4_7.AutoSize = true;
            this.lbl4_7.Location = new System.Drawing.Point(147, 489);
            this.lbl4_7.Name = "lbl4_7";
            this.lbl4_7.Size = new System.Drawing.Size(33, 13);
            this.lbl4_7.TabIndex = 159;
            this.lbl4_7.Text = "blank";
            // 
            // lbl18_5
            // 
            this.lbl18_5.AutoSize = true;
            this.lbl18_5.Location = new System.Drawing.Point(692, 351);
            this.lbl18_5.Name = "lbl18_5";
            this.lbl18_5.Size = new System.Drawing.Size(33, 13);
            this.lbl18_5.TabIndex = 158;
            this.lbl18_5.Text = "blank";
            // 
            // lbl14_5
            // 
            this.lbl14_5.AutoSize = true;
            this.lbl14_5.Location = new System.Drawing.Point(535, 351);
            this.lbl14_5.Name = "lbl14_5";
            this.lbl14_5.Size = new System.Drawing.Size(33, 13);
            this.lbl14_5.TabIndex = 157;
            this.lbl14_5.Text = "blank";
            // 
            // lbl10_5
            // 
            this.lbl10_5.AutoSize = true;
            this.lbl10_5.Location = new System.Drawing.Point(376, 351);
            this.lbl10_5.Name = "lbl10_5";
            this.lbl10_5.Size = new System.Drawing.Size(33, 13);
            this.lbl10_5.TabIndex = 156;
            this.lbl10_5.Text = "blank";
            // 
            // lbl6_5
            // 
            this.lbl6_5.AutoSize = true;
            this.lbl6_5.Location = new System.Drawing.Point(221, 351);
            this.lbl6_5.Name = "lbl6_5";
            this.lbl6_5.Size = new System.Drawing.Size(33, 13);
            this.lbl6_5.TabIndex = 155;
            this.lbl6_5.Text = "blank";
            // 
            // lbl2_5
            // 
            this.lbl2_5.AutoSize = true;
            this.lbl2_5.Location = new System.Drawing.Point(69, 356);
            this.lbl2_5.Name = "lbl2_5";
            this.lbl2_5.Size = new System.Drawing.Size(33, 13);
            this.lbl2_5.TabIndex = 154;
            this.lbl2_5.Text = "blank";
            // 
            // lbl16_3
            // 
            this.lbl16_3.AutoSize = true;
            this.lbl16_3.Location = new System.Drawing.Point(611, 214);
            this.lbl16_3.Name = "lbl16_3";
            this.lbl16_3.Size = new System.Drawing.Size(33, 13);
            this.lbl16_3.TabIndex = 153;
            this.lbl16_3.Text = "blank";
            // 
            // lbl12_3
            // 
            this.lbl12_3.AutoSize = true;
            this.lbl12_3.Location = new System.Drawing.Point(455, 214);
            this.lbl12_3.Name = "lbl12_3";
            this.lbl12_3.Size = new System.Drawing.Size(33, 13);
            this.lbl12_3.TabIndex = 152;
            this.lbl12_3.Text = "blank";
            // 
            // lbl8_3
            // 
            this.lbl8_3.AutoSize = true;
            this.lbl8_3.Location = new System.Drawing.Point(299, 214);
            this.lbl8_3.Name = "lbl8_3";
            this.lbl8_3.Size = new System.Drawing.Size(33, 13);
            this.lbl8_3.TabIndex = 151;
            this.lbl8_3.Text = "blank";
            // 
            // lbl4_3
            // 
            this.lbl4_3.AutoSize = true;
            this.lbl4_3.Location = new System.Drawing.Point(138, 214);
            this.lbl4_3.Name = "lbl4_3";
            this.lbl4_3.Size = new System.Drawing.Size(33, 13);
            this.lbl4_3.TabIndex = 150;
            this.lbl4_3.Text = "blank";
            // 
            // lbl14_1
            // 
            this.lbl14_1.AutoSize = true;
            this.lbl14_1.Location = new System.Drawing.Point(535, 89);
            this.lbl14_1.Name = "lbl14_1";
            this.lbl14_1.Size = new System.Drawing.Size(33, 13);
            this.lbl14_1.TabIndex = 149;
            this.lbl14_1.Text = "blank";
            // 
            // lbl10_1
            // 
            this.lbl10_1.AutoSize = true;
            this.lbl10_1.Location = new System.Drawing.Point(376, 89);
            this.lbl10_1.Name = "lbl10_1";
            this.lbl10_1.Size = new System.Drawing.Size(33, 13);
            this.lbl10_1.TabIndex = 148;
            this.lbl10_1.Text = "blank";
            // 
            // pbSettle0_4
            // 
            this.pbSettle0_4.Image = ((System.Drawing.Image)(resources.GetObject("pbSettle0_4.Image")));
            this.pbSettle0_4.Location = new System.Drawing.Point(-9, 306);
            this.pbSettle0_4.Name = "pbSettle0_4";
            this.pbSettle0_4.Size = new System.Drawing.Size(33, 27);
            this.pbSettle0_4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbSettle0_4.TabIndex = 119;
            this.pbSettle0_4.TabStop = false;
            this.pbSettle0_4.Tag = "settlement";
            this.pbSettle0_4.Click += new System.EventHandler(this.pbSettle0_4_Click);
            // 
            // pbSettle0_6
            // 
            this.pbSettle0_6.Image = ((System.Drawing.Image)(resources.GetObject("pbSettle0_6.Image")));
            this.pbSettle0_6.Location = new System.Drawing.Point(-9, 400);
            this.pbSettle0_6.Name = "pbSettle0_6";
            this.pbSettle0_6.Size = new System.Drawing.Size(33, 27);
            this.pbSettle0_6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbSettle0_6.TabIndex = 120;
            this.pbSettle0_6.TabStop = false;
            this.pbSettle0_6.Tag = "settlement";
            this.pbSettle0_6.Click += new System.EventHandler(this.pbSettle0_6_Click);
            // 
            // pbSettle14_10
            // 
            this.pbSettle14_10.Image = ((System.Drawing.Image)(resources.GetObject("pbSettle14_10.Image")));
            this.pbSettle14_10.Location = new System.Drawing.Point(535, 704);
            this.pbSettle14_10.Name = "pbSettle14_10";
            this.pbSettle14_10.Size = new System.Drawing.Size(33, 27);
            this.pbSettle14_10.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbSettle14_10.TabIndex = 146;
            this.pbSettle14_10.TabStop = false;
            this.pbSettle14_10.Tag = "settlement";
            this.pbSettle14_10.Click += new System.EventHandler(this.pbSettle14_10_Click);
            // 
            // pbSettle6_10
            // 
            this.pbSettle6_10.Image = ((System.Drawing.Image)(resources.GetObject("pbSettle6_10.Image")));
            this.pbSettle6_10.Location = new System.Drawing.Point(221, 704);
            this.pbSettle6_10.Name = "pbSettle6_10";
            this.pbSettle6_10.Size = new System.Drawing.Size(33, 27);
            this.pbSettle6_10.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbSettle6_10.TabIndex = 145;
            this.pbSettle6_10.TabStop = false;
            this.pbSettle6_10.Tag = "settlement";
            this.pbSettle6_10.Click += new System.EventHandler(this.pbSettle6_10_Click);
            // 
            // pbSettle10_10
            // 
            this.pbSettle10_10.Image = ((System.Drawing.Image)(resources.GetObject("pbSettle10_10.Image")));
            this.pbSettle10_10.Location = new System.Drawing.Point(375, 704);
            this.pbSettle10_10.Name = "pbSettle10_10";
            this.pbSettle10_10.Size = new System.Drawing.Size(33, 27);
            this.pbSettle10_10.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbSettle10_10.TabIndex = 144;
            this.pbSettle10_10.TabStop = false;
            this.pbSettle10_10.Tag = "settlement";
            this.pbSettle10_10.Click += new System.EventHandler(this.pbSettle10_10_Click);
            // 
            // pbSettle16_10
            // 
            this.pbSettle16_10.Image = ((System.Drawing.Image)(resources.GetObject("pbSettle16_10.Image")));
            this.pbSettle16_10.Location = new System.Drawing.Point(611, 658);
            this.pbSettle16_10.Name = "pbSettle16_10";
            this.pbSettle16_10.Size = new System.Drawing.Size(33, 27);
            this.pbSettle16_10.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbSettle16_10.TabIndex = 143;
            this.pbSettle16_10.TabStop = false;
            this.pbSettle16_10.Tag = "settlement";
            this.pbSettle16_10.Click += new System.EventHandler(this.pbSettle16_10_Click);
            // 
            // pbSettle12_10
            // 
            this.pbSettle12_10.Image = ((System.Drawing.Image)(resources.GetObject("pbSettle12_10.Image")));
            this.pbSettle12_10.Location = new System.Drawing.Point(455, 658);
            this.pbSettle12_10.Name = "pbSettle12_10";
            this.pbSettle12_10.Size = new System.Drawing.Size(33, 27);
            this.pbSettle12_10.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbSettle12_10.TabIndex = 142;
            this.pbSettle12_10.TabStop = false;
            this.pbSettle12_10.Tag = "settlement";
            this.pbSettle12_10.Click += new System.EventHandler(this.pbSettle12_10_Click);
            // 
            // pbSettle8_10
            // 
            this.pbSettle8_10.Image = ((System.Drawing.Image)(resources.GetObject("pbSettle8_10.Image")));
            this.pbSettle8_10.Location = new System.Drawing.Point(299, 658);
            this.pbSettle8_10.Name = "pbSettle8_10";
            this.pbSettle8_10.Size = new System.Drawing.Size(33, 27);
            this.pbSettle8_10.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbSettle8_10.TabIndex = 141;
            this.pbSettle8_10.TabStop = false;
            this.pbSettle8_10.Tag = "settlement";
            this.pbSettle8_10.Click += new System.EventHandler(this.pbSettle8_10_Click);
            // 
            // pbSettle4_10
            // 
            this.pbSettle4_10.Image = ((System.Drawing.Image)(resources.GetObject("pbSettle4_10.Image")));
            this.pbSettle4_10.Location = new System.Drawing.Point(147, 658);
            this.pbSettle4_10.Name = "pbSettle4_10";
            this.pbSettle4_10.Size = new System.Drawing.Size(33, 27);
            this.pbSettle4_10.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbSettle4_10.TabIndex = 140;
            this.pbSettle4_10.TabStop = false;
            this.pbSettle4_10.Tag = "settlement";
            this.pbSettle4_10.Click += new System.EventHandler(this.pbSettle4_10_Click);
            // 
            // pbSettle8_8
            // 
            this.pbSettle8_8.Image = ((System.Drawing.Image)(resources.GetObject("pbSettle8_8.Image")));
            this.pbSettle8_8.Location = new System.Drawing.Point(299, 583);
            this.pbSettle8_8.Name = "pbSettle8_8";
            this.pbSettle8_8.Size = new System.Drawing.Size(33, 27);
            this.pbSettle8_8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbSettle8_8.TabIndex = 139;
            this.pbSettle8_8.TabStop = false;
            this.pbSettle8_8.Tag = "settlement";
            this.pbSettle8_8.Click += new System.EventHandler(this.pbSettle8_8_Click);
            // 
            // pbSettle12_8
            // 
            this.pbSettle12_8.Image = ((System.Drawing.Image)(resources.GetObject("pbSettle12_8.Image")));
            this.pbSettle12_8.Location = new System.Drawing.Point(455, 583);
            this.pbSettle12_8.Name = "pbSettle12_8";
            this.pbSettle12_8.Size = new System.Drawing.Size(33, 27);
            this.pbSettle12_8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbSettle12_8.TabIndex = 138;
            this.pbSettle12_8.TabStop = false;
            this.pbSettle12_8.Tag = "settlement";
            this.pbSettle12_8.Click += new System.EventHandler(this.pbSettle12_8_Click);
            // 
            // pbSettle16_8
            // 
            this.pbSettle16_8.Image = ((System.Drawing.Image)(resources.GetObject("pbSettle16_8.Image")));
            this.pbSettle16_8.Location = new System.Drawing.Point(611, 583);
            this.pbSettle16_8.Name = "pbSettle16_8";
            this.pbSettle16_8.Size = new System.Drawing.Size(33, 27);
            this.pbSettle16_8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbSettle16_8.TabIndex = 137;
            this.pbSettle16_8.TabStop = false;
            this.pbSettle16_8.Tag = "settlement";
            this.pbSettle16_8.Click += new System.EventHandler(this.pbSettle16_8_Click);
            // 
            // pbSettle18_8
            // 
            this.pbSettle18_8.Image = ((System.Drawing.Image)(resources.GetObject("pbSettle18_8.Image")));
            this.pbSettle18_8.Location = new System.Drawing.Point(692, 525);
            this.pbSettle18_8.Name = "pbSettle18_8";
            this.pbSettle18_8.Size = new System.Drawing.Size(33, 27);
            this.pbSettle18_8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbSettle18_8.TabIndex = 136;
            this.pbSettle18_8.TabStop = false;
            this.pbSettle18_8.Tag = "settlement";
            this.pbSettle18_8.Click += new System.EventHandler(this.pbSettle18_8_Click);
            // 
            // pbSettle14_8
            // 
            this.pbSettle14_8.Image = ((System.Drawing.Image)(resources.GetObject("pbSettle14_8.Image")));
            this.pbSettle14_8.Location = new System.Drawing.Point(535, 534);
            this.pbSettle14_8.Name = "pbSettle14_8";
            this.pbSettle14_8.Size = new System.Drawing.Size(33, 27);
            this.pbSettle14_8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbSettle14_8.TabIndex = 135;
            this.pbSettle14_8.TabStop = false;
            this.pbSettle14_8.Tag = "settlement";
            this.pbSettle14_8.Click += new System.EventHandler(this.pbSettle14_8_Click);
            // 
            // pbSettle10_8
            // 
            this.pbSettle10_8.Image = ((System.Drawing.Image)(resources.GetObject("pbSettle10_8.Image")));
            this.pbSettle10_8.Location = new System.Drawing.Point(376, 534);
            this.pbSettle10_8.Name = "pbSettle10_8";
            this.pbSettle10_8.Size = new System.Drawing.Size(33, 27);
            this.pbSettle10_8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbSettle10_8.TabIndex = 134;
            this.pbSettle10_8.TabStop = false;
            this.pbSettle10_8.Tag = "settlement";
            this.pbSettle10_8.Click += new System.EventHandler(this.pbSettle10_8_Click);
            // 
            // pbSettle6_8
            // 
            this.pbSettle6_8.Image = ((System.Drawing.Image)(resources.GetObject("pbSettle6_8.Image")));
            this.pbSettle6_8.Location = new System.Drawing.Point(221, 534);
            this.pbSettle6_8.Name = "pbSettle6_8";
            this.pbSettle6_8.Size = new System.Drawing.Size(33, 27);
            this.pbSettle6_8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbSettle6_8.TabIndex = 133;
            this.pbSettle6_8.TabStop = false;
            this.pbSettle6_8.Tag = "settlement";
            this.pbSettle6_8.Click += new System.EventHandler(this.pbSettle6_8_Click);
            // 
            // pbSettle2_8
            // 
            this.pbSettle2_8.Image = ((System.Drawing.Image)(resources.GetObject("pbSettle2_8.Image")));
            this.pbSettle2_8.Location = new System.Drawing.Point(69, 525);
            this.pbSettle2_8.Name = "pbSettle2_8";
            this.pbSettle2_8.Size = new System.Drawing.Size(33, 27);
            this.pbSettle2_8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbSettle2_8.TabIndex = 132;
            this.pbSettle2_8.TabStop = false;
            this.pbSettle2_8.Tag = "settlement";
            this.pbSettle2_8.Click += new System.EventHandler(this.pbSettle2_8_Click);
            // 
            // pbSettle4_8
            // 
            this.pbSettle4_8.Image = ((System.Drawing.Image)(resources.GetObject("pbSettle4_8.Image")));
            this.pbSettle4_8.Location = new System.Drawing.Point(147, 572);
            this.pbSettle4_8.Name = "pbSettle4_8";
            this.pbSettle4_8.Size = new System.Drawing.Size(33, 27);
            this.pbSettle4_8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbSettle4_8.TabIndex = 131;
            this.pbSettle4_8.TabStop = false;
            this.pbSettle4_8.Tag = "settlement";
            this.pbSettle4_8.Click += new System.EventHandler(this.pbSettle4_8_Click);
            // 
            // pbSettle20_6
            // 
            this.pbSettle20_6.Image = ((System.Drawing.Image)(resources.GetObject("pbSettle20_6.Image")));
            this.pbSettle20_6.Location = new System.Drawing.Point(762, 400);
            this.pbSettle20_6.Name = "pbSettle20_6";
            this.pbSettle20_6.Size = new System.Drawing.Size(33, 27);
            this.pbSettle20_6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbSettle20_6.TabIndex = 130;
            this.pbSettle20_6.TabStop = false;
            this.pbSettle20_6.Tag = "settlement";
            this.pbSettle20_6.Click += new System.EventHandler(this.pbSettle20_6_Click);
            // 
            // pbSettle18_6
            // 
            this.pbSettle18_6.Image = ((System.Drawing.Image)(resources.GetObject("pbSettle18_6.Image")));
            this.pbSettle18_6.Location = new System.Drawing.Point(692, 439);
            this.pbSettle18_6.Name = "pbSettle18_6";
            this.pbSettle18_6.Size = new System.Drawing.Size(33, 27);
            this.pbSettle18_6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbSettle18_6.TabIndex = 129;
            this.pbSettle18_6.TabStop = false;
            this.pbSettle18_6.Tag = "settlement";
            this.pbSettle18_6.Click += new System.EventHandler(this.pbSettle18_6_Click);
            // 
            // pbSettle16_6
            // 
            this.pbSettle16_6.Image = ((System.Drawing.Image)(resources.GetObject("pbSettle16_6.Image")));
            this.pbSettle16_6.Location = new System.Drawing.Point(611, 400);
            this.pbSettle16_6.Name = "pbSettle16_6";
            this.pbSettle16_6.Size = new System.Drawing.Size(33, 27);
            this.pbSettle16_6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbSettle16_6.TabIndex = 128;
            this.pbSettle16_6.TabStop = false;
            this.pbSettle16_6.Tag = "settlement";
            this.pbSettle16_6.Click += new System.EventHandler(this.pbSettle16_6_Click);
            // 
            // pbSettle14_6
            // 
            this.pbSettle14_6.Image = ((System.Drawing.Image)(resources.GetObject("pbSettle14_6.Image")));
            this.pbSettle14_6.Location = new System.Drawing.Point(535, 439);
            this.pbSettle14_6.Name = "pbSettle14_6";
            this.pbSettle14_6.Size = new System.Drawing.Size(33, 27);
            this.pbSettle14_6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbSettle14_6.TabIndex = 127;
            this.pbSettle14_6.TabStop = false;
            this.pbSettle14_6.Tag = "settlement";
            this.pbSettle14_6.Click += new System.EventHandler(this.pbSettle14_6_Click);
            // 
            // pbSettle12_6
            // 
            this.pbSettle12_6.Image = ((System.Drawing.Image)(resources.GetObject("pbSettle12_6.Image")));
            this.pbSettle12_6.Location = new System.Drawing.Point(455, 400);
            this.pbSettle12_6.Name = "pbSettle12_6";
            this.pbSettle12_6.Size = new System.Drawing.Size(33, 27);
            this.pbSettle12_6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbSettle12_6.TabIndex = 126;
            this.pbSettle12_6.TabStop = false;
            this.pbSettle12_6.Tag = "settlement";
            this.pbSettle12_6.Click += new System.EventHandler(this.pbSettle12_6_Click);
            // 
            // pbSettle10_6
            // 
            this.pbSettle10_6.Image = ((System.Drawing.Image)(resources.GetObject("pbSettle10_6.Image")));
            this.pbSettle10_6.Location = new System.Drawing.Point(376, 439);
            this.pbSettle10_6.Name = "pbSettle10_6";
            this.pbSettle10_6.Size = new System.Drawing.Size(33, 27);
            this.pbSettle10_6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbSettle10_6.TabIndex = 125;
            this.pbSettle10_6.TabStop = false;
            this.pbSettle10_6.Tag = "settlement";
            this.pbSettle10_6.Click += new System.EventHandler(this.pbSettle10_6_Click);
            // 
            // pbSettle8_6
            // 
            this.pbSettle8_6.Image = ((System.Drawing.Image)(resources.GetObject("pbSettle8_6.Image")));
            this.pbSettle8_6.Location = new System.Drawing.Point(299, 400);
            this.pbSettle8_6.Name = "pbSettle8_6";
            this.pbSettle8_6.Size = new System.Drawing.Size(33, 27);
            this.pbSettle8_6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbSettle8_6.TabIndex = 124;
            this.pbSettle8_6.TabStop = false;
            this.pbSettle8_6.Tag = "settlement";
            this.pbSettle8_6.Click += new System.EventHandler(this.pbSettle8_6_Click);
            // 
            // pbSettle6_6
            // 
            this.pbSettle6_6.Image = ((System.Drawing.Image)(resources.GetObject("pbSettle6_6.Image")));
            this.pbSettle6_6.Location = new System.Drawing.Point(221, 439);
            this.pbSettle6_6.Name = "pbSettle6_6";
            this.pbSettle6_6.Size = new System.Drawing.Size(33, 27);
            this.pbSettle6_6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbSettle6_6.TabIndex = 123;
            this.pbSettle6_6.TabStop = false;
            this.pbSettle6_6.Tag = "settlement";
            this.pbSettle6_6.Click += new System.EventHandler(this.pbSettle6_6_Click);
            // 
            // pbSettle2_6
            // 
            this.pbSettle2_6.Image = ((System.Drawing.Image)(resources.GetObject("pbSettle2_6.Image")));
            this.pbSettle2_6.Location = new System.Drawing.Point(69, 433);
            this.pbSettle2_6.Name = "pbSettle2_6";
            this.pbSettle2_6.Size = new System.Drawing.Size(33, 27);
            this.pbSettle2_6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbSettle2_6.TabIndex = 122;
            this.pbSettle2_6.TabStop = false;
            this.pbSettle2_6.Tag = "settlement";
            this.pbSettle2_6.Click += new System.EventHandler(this.pbSettle2_6_Click);
            // 
            // pbSettle4_6
            // 
            this.pbSettle4_6.Image = ((System.Drawing.Image)(resources.GetObject("pbSettle4_6.Image")));
            this.pbSettle4_6.Location = new System.Drawing.Point(147, 400);
            this.pbSettle4_6.Name = "pbSettle4_6";
            this.pbSettle4_6.Size = new System.Drawing.Size(33, 27);
            this.pbSettle4_6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbSettle4_6.TabIndex = 121;
            this.pbSettle4_6.TabStop = false;
            this.pbSettle4_6.Tag = "settlement";
            this.pbSettle4_6.Click += new System.EventHandler(this.pbSettle4_6_Click);
            // 
            // pbSettle20_4
            // 
            this.pbSettle20_4.Image = ((System.Drawing.Image)(resources.GetObject("pbSettle20_4.Image")));
            this.pbSettle20_4.Location = new System.Drawing.Point(762, 306);
            this.pbSettle20_4.Name = "pbSettle20_4";
            this.pbSettle20_4.Size = new System.Drawing.Size(33, 27);
            this.pbSettle20_4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbSettle20_4.TabIndex = 118;
            this.pbSettle20_4.TabStop = false;
            this.pbSettle20_4.Tag = "settlement";
            this.pbSettle20_4.Click += new System.EventHandler(this.pbSettle20_4_Click);
            // 
            // pbSettle18_4
            // 
            this.pbSettle18_4.Image = ((System.Drawing.Image)(resources.GetObject("pbSettle18_4.Image")));
            this.pbSettle18_4.Location = new System.Drawing.Point(692, 262);
            this.pbSettle18_4.Name = "pbSettle18_4";
            this.pbSettle18_4.Size = new System.Drawing.Size(33, 27);
            this.pbSettle18_4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbSettle18_4.TabIndex = 117;
            this.pbSettle18_4.TabStop = false;
            this.pbSettle18_4.Tag = "settlement";
            this.pbSettle18_4.Click += new System.EventHandler(this.pbSettle18_4_Click);
            // 
            // pbSettle16_4
            // 
            this.pbSettle16_4.Image = ((System.Drawing.Image)(resources.GetObject("pbSettle16_4.Image")));
            this.pbSettle16_4.Location = new System.Drawing.Point(611, 306);
            this.pbSettle16_4.Name = "pbSettle16_4";
            this.pbSettle16_4.Size = new System.Drawing.Size(33, 27);
            this.pbSettle16_4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbSettle16_4.TabIndex = 116;
            this.pbSettle16_4.TabStop = false;
            this.pbSettle16_4.Tag = "settlement";
            this.pbSettle16_4.Click += new System.EventHandler(this.pbSettle16_4_Click);
            // 
            // pbSettle14_4
            // 
            this.pbSettle14_4.Image = ((System.Drawing.Image)(resources.GetObject("pbSettle14_4.Image")));
            this.pbSettle14_4.Location = new System.Drawing.Point(535, 262);
            this.pbSettle14_4.Name = "pbSettle14_4";
            this.pbSettle14_4.Size = new System.Drawing.Size(33, 27);
            this.pbSettle14_4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbSettle14_4.TabIndex = 115;
            this.pbSettle14_4.TabStop = false;
            this.pbSettle14_4.Tag = "settlement";
            this.pbSettle14_4.Click += new System.EventHandler(this.pbSettle14_4_Click);
            // 
            // pbSettle12_4
            // 
            this.pbSettle12_4.Image = ((System.Drawing.Image)(resources.GetObject("pbSettle12_4.Image")));
            this.pbSettle12_4.Location = new System.Drawing.Point(455, 306);
            this.pbSettle12_4.Name = "pbSettle12_4";
            this.pbSettle12_4.Size = new System.Drawing.Size(33, 27);
            this.pbSettle12_4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbSettle12_4.TabIndex = 114;
            this.pbSettle12_4.TabStop = false;
            this.pbSettle12_4.Tag = "settlement";
            this.pbSettle12_4.Click += new System.EventHandler(this.pbSettle12_4_Click);
            // 
            // pbSettle10_4
            // 
            this.pbSettle10_4.Image = ((System.Drawing.Image)(resources.GetObject("pbSettle10_4.Image")));
            this.pbSettle10_4.Location = new System.Drawing.Point(376, 262);
            this.pbSettle10_4.Name = "pbSettle10_4";
            this.pbSettle10_4.Size = new System.Drawing.Size(33, 27);
            this.pbSettle10_4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbSettle10_4.TabIndex = 113;
            this.pbSettle10_4.TabStop = false;
            this.pbSettle10_4.Tag = "settlement";
            this.pbSettle10_4.Click += new System.EventHandler(this.pbSettle10_4_Click);
            // 
            // pbSettle4_4
            // 
            this.pbSettle4_4.Image = ((System.Drawing.Image)(resources.GetObject("pbSettle4_4.Image")));
            this.pbSettle4_4.Location = new System.Drawing.Point(147, 306);
            this.pbSettle4_4.Name = "pbSettle4_4";
            this.pbSettle4_4.Size = new System.Drawing.Size(33, 27);
            this.pbSettle4_4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbSettle4_4.TabIndex = 112;
            this.pbSettle4_4.TabStop = false;
            this.pbSettle4_4.Tag = "settlement";
            this.pbSettle4_4.Click += new System.EventHandler(this.pbSettle4_4_Click);
            // 
            // pbSettle8_4
            // 
            this.pbSettle8_4.Image = ((System.Drawing.Image)(resources.GetObject("pbSettle8_4.Image")));
            this.pbSettle8_4.Location = new System.Drawing.Point(299, 306);
            this.pbSettle8_4.Name = "pbSettle8_4";
            this.pbSettle8_4.Size = new System.Drawing.Size(33, 27);
            this.pbSettle8_4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbSettle8_4.TabIndex = 111;
            this.pbSettle8_4.TabStop = false;
            this.pbSettle8_4.Tag = "settlement";
            this.pbSettle8_4.Click += new System.EventHandler(this.pbSettle8_4_Click);
            // 
            // pbSettle6_4
            // 
            this.pbSettle6_4.Image = ((System.Drawing.Image)(resources.GetObject("pbSettle6_4.Image")));
            this.pbSettle6_4.Location = new System.Drawing.Point(221, 262);
            this.pbSettle6_4.Name = "pbSettle6_4";
            this.pbSettle6_4.Size = new System.Drawing.Size(33, 27);
            this.pbSettle6_4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbSettle6_4.TabIndex = 110;
            this.pbSettle6_4.TabStop = false;
            this.pbSettle6_4.Tag = "settlement";
            this.pbSettle6_4.Click += new System.EventHandler(this.pbSettle6_4_Click);
            // 
            // pbSettle2_4
            // 
            this.pbSettle2_4.Image = ((System.Drawing.Image)(resources.GetObject("pbSettle2_4.Image")));
            this.pbSettle2_4.Location = new System.Drawing.Point(60, 262);
            this.pbSettle2_4.Name = "pbSettle2_4";
            this.pbSettle2_4.Size = new System.Drawing.Size(33, 27);
            this.pbSettle2_4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbSettle2_4.TabIndex = 109;
            this.pbSettle2_4.TabStop = false;
            this.pbSettle2_4.Tag = "settlement";
            this.pbSettle2_4.Click += new System.EventHandler(this.pbSettle2_4_Click);
            // 
            // pbSettle2_2
            // 
            this.pbSettle2_2.Image = ((System.Drawing.Image)(resources.GetObject("pbSettle2_2.Image")));
            this.pbSettle2_2.Location = new System.Drawing.Point(69, 166);
            this.pbSettle2_2.Name = "pbSettle2_2";
            this.pbSettle2_2.Size = new System.Drawing.Size(33, 27);
            this.pbSettle2_2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbSettle2_2.TabIndex = 108;
            this.pbSettle2_2.TabStop = false;
            this.pbSettle2_2.Tag = "settlement";
            this.pbSettle2_2.Click += new System.EventHandler(this.pbSettle2_2_Click);
            // 
            // pbSettle18_2
            // 
            this.pbSettle18_2.Image = ((System.Drawing.Image)(resources.GetObject("pbSettle18_2.Image")));
            this.pbSettle18_2.Location = new System.Drawing.Point(683, 166);
            this.pbSettle18_2.Name = "pbSettle18_2";
            this.pbSettle18_2.Size = new System.Drawing.Size(33, 27);
            this.pbSettle18_2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbSettle18_2.TabIndex = 107;
            this.pbSettle18_2.TabStop = false;
            this.pbSettle18_2.Tag = "settlement";
            this.pbSettle18_2.Click += new System.EventHandler(this.pbSettle18_2_Click);
            // 
            // pbSettle12_2
            // 
            this.pbSettle12_2.Image = ((System.Drawing.Image)(resources.GetObject("pbSettle12_2.Image")));
            this.pbSettle12_2.Location = new System.Drawing.Point(455, 124);
            this.pbSettle12_2.Name = "pbSettle12_2";
            this.pbSettle12_2.Size = new System.Drawing.Size(33, 27);
            this.pbSettle12_2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbSettle12_2.TabIndex = 106;
            this.pbSettle12_2.TabStop = false;
            this.pbSettle12_2.Tag = "settlement";
            this.pbSettle12_2.Click += new System.EventHandler(this.pbSettle12_2_Click);
            // 
            // pbSettle16_2
            // 
            this.pbSettle16_2.Image = ((System.Drawing.Image)(resources.GetObject("pbSettle16_2.Image")));
            this.pbSettle16_2.Location = new System.Drawing.Point(611, 124);
            this.pbSettle16_2.Name = "pbSettle16_2";
            this.pbSettle16_2.Size = new System.Drawing.Size(33, 27);
            this.pbSettle16_2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbSettle16_2.TabIndex = 105;
            this.pbSettle16_2.TabStop = false;
            this.pbSettle16_2.Tag = "settlement";
            this.pbSettle16_2.Click += new System.EventHandler(this.pbSettle16_2_Click);
            // 
            // pbSettle14_2
            // 
            this.pbSettle14_2.Image = ((System.Drawing.Image)(resources.GetObject("pbSettle14_2.Image")));
            this.pbSettle14_2.Location = new System.Drawing.Point(535, 166);
            this.pbSettle14_2.Name = "pbSettle14_2";
            this.pbSettle14_2.Size = new System.Drawing.Size(33, 27);
            this.pbSettle14_2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbSettle14_2.TabIndex = 104;
            this.pbSettle14_2.TabStop = false;
            this.pbSettle14_2.Tag = "settlement";
            this.pbSettle14_2.Click += new System.EventHandler(this.pbSettle14_2_Click);
            // 
            // pbSettle10_2
            // 
            this.pbSettle10_2.Image = ((System.Drawing.Image)(resources.GetObject("pbSettle10_2.Image")));
            this.pbSettle10_2.Location = new System.Drawing.Point(376, 166);
            this.pbSettle10_2.Name = "pbSettle10_2";
            this.pbSettle10_2.Size = new System.Drawing.Size(33, 27);
            this.pbSettle10_2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbSettle10_2.TabIndex = 103;
            this.pbSettle10_2.TabStop = false;
            this.pbSettle10_2.Tag = "settlement";
            this.pbSettle10_2.Click += new System.EventHandler(this.pbSettle10_2_Click);
            // 
            // pbSettle8_2
            // 
            this.pbSettle8_2.Image = ((System.Drawing.Image)(resources.GetObject("pbSettle8_2.Image")));
            this.pbSettle8_2.Location = new System.Drawing.Point(299, 124);
            this.pbSettle8_2.Name = "pbSettle8_2";
            this.pbSettle8_2.Size = new System.Drawing.Size(33, 27);
            this.pbSettle8_2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbSettle8_2.TabIndex = 102;
            this.pbSettle8_2.TabStop = false;
            this.pbSettle8_2.Tag = "settlement";
            this.pbSettle8_2.Click += new System.EventHandler(this.pbSettle8_2_Click);
            // 
            // pbSettle6_2
            // 
            this.pbSettle6_2.Image = ((System.Drawing.Image)(resources.GetObject("pbSettle6_2.Image")));
            this.pbSettle6_2.Location = new System.Drawing.Point(221, 166);
            this.pbSettle6_2.Name = "pbSettle6_2";
            this.pbSettle6_2.Size = new System.Drawing.Size(33, 27);
            this.pbSettle6_2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbSettle6_2.TabIndex = 101;
            this.pbSettle6_2.TabStop = false;
            this.pbSettle6_2.Tag = "settlement";
            this.pbSettle6_2.Click += new System.EventHandler(this.pbSettle6_2_Click);
            // 
            // pbSettle4_2
            // 
            this.pbSettle4_2.Image = ((System.Drawing.Image)(resources.GetObject("pbSettle4_2.Image")));
            this.pbSettle4_2.Location = new System.Drawing.Point(138, 124);
            this.pbSettle4_2.Name = "pbSettle4_2";
            this.pbSettle4_2.Size = new System.Drawing.Size(33, 27);
            this.pbSettle4_2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbSettle4_2.TabIndex = 100;
            this.pbSettle4_2.TabStop = false;
            this.pbSettle4_2.Tag = "settlement";
            this.pbSettle4_2.Click += new System.EventHandler(this.pbSettle4_2_Click);
            // 
            // pbSettle16_0
            // 
            this.pbSettle16_0.Image = ((System.Drawing.Image)(resources.GetObject("pbSettle16_0.Image")));
            this.pbSettle16_0.Location = new System.Drawing.Point(611, 48);
            this.pbSettle16_0.Name = "pbSettle16_0";
            this.pbSettle16_0.Size = new System.Drawing.Size(33, 27);
            this.pbSettle16_0.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbSettle16_0.TabIndex = 99;
            this.pbSettle16_0.TabStop = false;
            this.pbSettle16_0.Tag = "settlement";
            this.pbSettle16_0.Click += new System.EventHandler(this.pbSettle16_0_Click);
            // 
            // pbSettle12_0
            // 
            this.pbSettle12_0.Image = ((System.Drawing.Image)(resources.GetObject("pbSettle12_0.Image")));
            this.pbSettle12_0.Location = new System.Drawing.Point(455, 48);
            this.pbSettle12_0.Name = "pbSettle12_0";
            this.pbSettle12_0.Size = new System.Drawing.Size(33, 27);
            this.pbSettle12_0.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbSettle12_0.TabIndex = 98;
            this.pbSettle12_0.TabStop = false;
            this.pbSettle12_0.Tag = "settlement";
            this.pbSettle12_0.Click += new System.EventHandler(this.pbSettle12_0_Click);
            // 
            // pbSettle8_0
            // 
            this.pbSettle8_0.Image = ((System.Drawing.Image)(resources.GetObject("pbSettle8_0.Image")));
            this.pbSettle8_0.Location = new System.Drawing.Point(299, 48);
            this.pbSettle8_0.Name = "pbSettle8_0";
            this.pbSettle8_0.Size = new System.Drawing.Size(33, 27);
            this.pbSettle8_0.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbSettle8_0.TabIndex = 97;
            this.pbSettle8_0.TabStop = false;
            this.pbSettle8_0.Tag = "settlement";
            this.pbSettle8_0.Click += new System.EventHandler(this.pbSettle8_0_Click);
            // 
            // pbSettle4_0
            // 
            this.pbSettle4_0.Image = ((System.Drawing.Image)(resources.GetObject("pbSettle4_0.Image")));
            this.pbSettle4_0.Location = new System.Drawing.Point(138, 48);
            this.pbSettle4_0.Name = "pbSettle4_0";
            this.pbSettle4_0.Size = new System.Drawing.Size(33, 27);
            this.pbSettle4_0.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbSettle4_0.TabIndex = 96;
            this.pbSettle4_0.TabStop = false;
            this.pbSettle4_0.Tag = "settlement";
            this.pbSettle4_0.Click += new System.EventHandler(this.pbSettle4_0_Click);
            // 
            // pbSettle14_0
            // 
            this.pbSettle14_0.Image = ((System.Drawing.Image)(resources.GetObject("pbSettle14_0.Image")));
            this.pbSettle14_0.Location = new System.Drawing.Point(535, 0);
            this.pbSettle14_0.Name = "pbSettle14_0";
            this.pbSettle14_0.Size = new System.Drawing.Size(33, 27);
            this.pbSettle14_0.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbSettle14_0.TabIndex = 95;
            this.pbSettle14_0.TabStop = false;
            this.pbSettle14_0.Tag = "settlement";
            this.pbSettle14_0.Click += new System.EventHandler(this.pbSettle14_0_Click);
            // 
            // pbSettle10_0
            // 
            this.pbSettle10_0.Image = ((System.Drawing.Image)(resources.GetObject("pbSettle10_0.Image")));
            this.pbSettle10_0.Location = new System.Drawing.Point(376, 0);
            this.pbSettle10_0.Name = "pbSettle10_0";
            this.pbSettle10_0.Size = new System.Drawing.Size(33, 27);
            this.pbSettle10_0.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbSettle10_0.TabIndex = 94;
            this.pbSettle10_0.TabStop = false;
            this.pbSettle10_0.Tag = "settlement";
            this.pbSettle10_0.Click += new System.EventHandler(this.pbSettle10_0_Click);
            // 
            // pbSettle6_0
            // 
            this.pbSettle6_0.Image = global::OrangeCatans.Properties.Resources.settlementBase;
            this.pbSettle6_0.Location = new System.Drawing.Point(221, 0);
            this.pbSettle6_0.Name = "pbSettle6_0";
            this.pbSettle6_0.Size = new System.Drawing.Size(33, 27);
            this.pbSettle6_0.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbSettle6_0.TabIndex = 93;
            this.pbSettle6_0.TabStop = false;
            this.pbSettle6_0.Tag = "settlement";
            this.pbSettle6_0.Click += new System.EventHandler(this.pbSettle6_0_Click);
            // 
            // pbRoad11_6
            // 
            this.pbRoad11_6.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.pbRoad11_6.Image = ((System.Drawing.Image)(resources.GetObject("pbRoad11_6.Image")));
            this.pbRoad11_6.Location = new System.Drawing.Point(425, 375);
            this.pbRoad11_6.Name = "pbRoad11_6";
            this.pbRoad11_6.Size = new System.Drawing.Size(24, 85);
            this.pbRoad11_6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbRoad11_6.TabIndex = 92;
            this.pbRoad11_6.TabStop = false;
            this.pbRoad11_6.Tag = "road";
            this.pbRoad11_6.Click += new System.EventHandler(this.pbRoad11_6_Click);
            // 
            // pbRoad17_8
            // 
            this.pbRoad17_8.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.pbRoad17_8.Image = ((System.Drawing.Image)(resources.GetObject("pbRoad17_8.Image")));
            this.pbRoad17_8.Location = new System.Drawing.Point(662, 525);
            this.pbRoad17_8.Name = "pbRoad17_8";
            this.pbRoad17_8.Size = new System.Drawing.Size(24, 85);
            this.pbRoad17_8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbRoad17_8.TabIndex = 91;
            this.pbRoad17_8.TabStop = false;
            this.pbRoad17_8.Tag = "road";
            this.pbRoad17_8.Click += new System.EventHandler(this.pbRoad17_8_Click);
            // 
            // pbRoad15_10
            // 
            this.pbRoad15_10.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.pbRoad15_10.Image = ((System.Drawing.Image)(resources.GetObject("pbRoad15_10.Image")));
            this.pbRoad15_10.Location = new System.Drawing.Point(581, 646);
            this.pbRoad15_10.Name = "pbRoad15_10";
            this.pbRoad15_10.Size = new System.Drawing.Size(24, 85);
            this.pbRoad15_10.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbRoad15_10.TabIndex = 90;
            this.pbRoad15_10.TabStop = false;
            this.pbRoad15_10.Tag = "road";
            this.pbRoad15_10.Click += new System.EventHandler(this.pbRoad15_10_Click);
            // 
            // pbRoad13_10
            // 
            this.pbRoad13_10.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.pbRoad13_10.Image = ((System.Drawing.Image)(resources.GetObject("pbRoad13_10.Image")));
            this.pbRoad13_10.Location = new System.Drawing.Point(505, 646);
            this.pbRoad13_10.Name = "pbRoad13_10";
            this.pbRoad13_10.Size = new System.Drawing.Size(24, 85);
            this.pbRoad13_10.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbRoad13_10.TabIndex = 89;
            this.pbRoad13_10.TabStop = false;
            this.pbRoad13_10.Tag = "road";
            this.pbRoad13_10.Click += new System.EventHandler(this.pbRoad13_10_Click);
            // 
            // pbRoad11_10
            // 
            this.pbRoad11_10.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.pbRoad11_10.Image = ((System.Drawing.Image)(resources.GetObject("pbRoad11_10.Image")));
            this.pbRoad11_10.Location = new System.Drawing.Point(425, 646);
            this.pbRoad11_10.Name = "pbRoad11_10";
            this.pbRoad11_10.Size = new System.Drawing.Size(24, 85);
            this.pbRoad11_10.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbRoad11_10.TabIndex = 88;
            this.pbRoad11_10.TabStop = false;
            this.pbRoad11_10.Tag = "road";
            this.pbRoad11_10.Click += new System.EventHandler(this.pbRoad11_10_Click);
            // 
            // pbRoad9_10
            // 
            this.pbRoad9_10.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.pbRoad9_10.Image = ((System.Drawing.Image)(resources.GetObject("pbRoad9_10.Image")));
            this.pbRoad9_10.Location = new System.Drawing.Point(345, 646);
            this.pbRoad9_10.Name = "pbRoad9_10";
            this.pbRoad9_10.Size = new System.Drawing.Size(24, 85);
            this.pbRoad9_10.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbRoad9_10.TabIndex = 87;
            this.pbRoad9_10.TabStop = false;
            this.pbRoad9_10.Tag = "road";
            this.pbRoad9_10.Click += new System.EventHandler(this.pbRoad9_10_Click);
            // 
            // pbRoad7_10
            // 
            this.pbRoad7_10.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.pbRoad7_10.Image = ((System.Drawing.Image)(resources.GetObject("pbRoad7_10.Image")));
            this.pbRoad7_10.Location = new System.Drawing.Point(269, 646);
            this.pbRoad7_10.Name = "pbRoad7_10";
            this.pbRoad7_10.Size = new System.Drawing.Size(24, 85);
            this.pbRoad7_10.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbRoad7_10.TabIndex = 86;
            this.pbRoad7_10.TabStop = false;
            this.pbRoad7_10.Tag = "road";
            this.pbRoad7_10.Click += new System.EventHandler(this.pbRoad7_10_Click);
            // 
            // pbRoad5_10
            // 
            this.pbRoad5_10.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.pbRoad5_10.Image = ((System.Drawing.Image)(resources.GetObject("pbRoad5_10.Image")));
            this.pbRoad5_10.Location = new System.Drawing.Point(189, 646);
            this.pbRoad5_10.Name = "pbRoad5_10";
            this.pbRoad5_10.Size = new System.Drawing.Size(24, 85);
            this.pbRoad5_10.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbRoad5_10.TabIndex = 85;
            this.pbRoad5_10.TabStop = false;
            this.pbRoad5_10.Tag = "road";
            this.pbRoad5_10.Click += new System.EventHandler(this.pbRoad5_10_Click);
            // 
            // pbRoad16_9
            // 
            this.pbRoad16_9.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.pbRoad16_9.Image = ((System.Drawing.Image)(resources.GetObject("pbRoad16_9.Image")));
            this.pbRoad16_9.Location = new System.Drawing.Point(611, 600);
            this.pbRoad16_9.Name = "pbRoad16_9";
            this.pbRoad16_9.Size = new System.Drawing.Size(24, 85);
            this.pbRoad16_9.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbRoad16_9.TabIndex = 84;
            this.pbRoad16_9.TabStop = false;
            this.pbRoad16_9.Tag = "road";
            this.pbRoad16_9.Click += new System.EventHandler(this.pbRoad16_9_Click);
            // 
            // pbRoad12_9
            // 
            this.pbRoad12_9.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.pbRoad12_9.Image = ((System.Drawing.Image)(resources.GetObject("pbRoad12_9.Image")));
            this.pbRoad12_9.Location = new System.Drawing.Point(464, 600);
            this.pbRoad12_9.Name = "pbRoad12_9";
            this.pbRoad12_9.Size = new System.Drawing.Size(24, 85);
            this.pbRoad12_9.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbRoad12_9.TabIndex = 83;
            this.pbRoad12_9.TabStop = false;
            this.pbRoad12_9.Tag = "road";
            this.pbRoad12_9.Click += new System.EventHandler(this.pbRoad12_9_Click);
            // 
            // pbRoad8_9
            // 
            this.pbRoad8_9.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.pbRoad8_9.Image = ((System.Drawing.Image)(resources.GetObject("pbRoad8_9.Image")));
            this.pbRoad8_9.Location = new System.Drawing.Point(299, 591);
            this.pbRoad8_9.Name = "pbRoad8_9";
            this.pbRoad8_9.Size = new System.Drawing.Size(24, 85);
            this.pbRoad8_9.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbRoad8_9.TabIndex = 82;
            this.pbRoad8_9.TabStop = false;
            this.pbRoad8_9.Tag = "road";
            this.pbRoad8_9.Click += new System.EventHandler(this.pbRoad8_9_Click);
            // 
            // pbRoad4_9
            // 
            this.pbRoad4_9.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.pbRoad4_9.Image = ((System.Drawing.Image)(resources.GetObject("pbRoad4_9.Image")));
            this.pbRoad4_9.Location = new System.Drawing.Point(147, 591);
            this.pbRoad4_9.Name = "pbRoad4_9";
            this.pbRoad4_9.Size = new System.Drawing.Size(24, 85);
            this.pbRoad4_9.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbRoad4_9.TabIndex = 81;
            this.pbRoad4_9.TabStop = false;
            this.pbRoad4_9.Tag = "road";
            this.pbRoad4_9.Click += new System.EventHandler(this.pbRoad4_9_Click);
            // 
            // pbRoad15_8
            // 
            this.pbRoad15_8.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.pbRoad15_8.Image = ((System.Drawing.Image)(resources.GetObject("pbRoad15_8.Image")));
            this.pbRoad15_8.Location = new System.Drawing.Point(581, 525);
            this.pbRoad15_8.Name = "pbRoad15_8";
            this.pbRoad15_8.Size = new System.Drawing.Size(24, 85);
            this.pbRoad15_8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbRoad15_8.TabIndex = 80;
            this.pbRoad15_8.TabStop = false;
            this.pbRoad15_8.Tag = "road";
            this.pbRoad15_8.Click += new System.EventHandler(this.pbRoad15_8_Click);
            // 
            // pbRoad13_8
            // 
            this.pbRoad13_8.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.pbRoad13_8.Image = ((System.Drawing.Image)(resources.GetObject("pbRoad13_8.Image")));
            this.pbRoad13_8.Location = new System.Drawing.Point(505, 525);
            this.pbRoad13_8.Name = "pbRoad13_8";
            this.pbRoad13_8.Size = new System.Drawing.Size(24, 85);
            this.pbRoad13_8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbRoad13_8.TabIndex = 79;
            this.pbRoad13_8.TabStop = false;
            this.pbRoad13_8.Tag = "road";
            this.pbRoad13_8.Click += new System.EventHandler(this.pbRoad13_8_Click);
            // 
            // pbRoad11_8
            // 
            this.pbRoad11_8.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.pbRoad11_8.Image = ((System.Drawing.Image)(resources.GetObject("pbRoad11_8.Image")));
            this.pbRoad11_8.Location = new System.Drawing.Point(425, 525);
            this.pbRoad11_8.Name = "pbRoad11_8";
            this.pbRoad11_8.Size = new System.Drawing.Size(24, 85);
            this.pbRoad11_8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbRoad11_8.TabIndex = 78;
            this.pbRoad11_8.TabStop = false;
            this.pbRoad11_8.Tag = "road";
            this.pbRoad11_8.Click += new System.EventHandler(this.pbRoad11_8_Click);
            // 
            // pbRoad9_8
            // 
            this.pbRoad9_8.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.pbRoad9_8.Image = ((System.Drawing.Image)(resources.GetObject("pbRoad9_8.Image")));
            this.pbRoad9_8.Location = new System.Drawing.Point(345, 525);
            this.pbRoad9_8.Name = "pbRoad9_8";
            this.pbRoad9_8.Size = new System.Drawing.Size(24, 85);
            this.pbRoad9_8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbRoad9_8.TabIndex = 77;
            this.pbRoad9_8.TabStop = false;
            this.pbRoad9_8.Tag = "road";
            this.pbRoad9_8.Click += new System.EventHandler(this.pbRoad9_8_Click);
            // 
            // pbRoad7_8
            // 
            this.pbRoad7_8.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.pbRoad7_8.Image = ((System.Drawing.Image)(resources.GetObject("pbRoad7_8.Image")));
            this.pbRoad7_8.Location = new System.Drawing.Point(269, 525);
            this.pbRoad7_8.Name = "pbRoad7_8";
            this.pbRoad7_8.Size = new System.Drawing.Size(24, 85);
            this.pbRoad7_8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbRoad7_8.TabIndex = 76;
            this.pbRoad7_8.TabStop = false;
            this.pbRoad7_8.Tag = "road";
            this.pbRoad7_8.Click += new System.EventHandler(this.pbRoad7_8_Click);
            // 
            // pbRoad5_8
            // 
            this.pbRoad5_8.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.pbRoad5_8.Image = ((System.Drawing.Image)(resources.GetObject("pbRoad5_8.Image")));
            this.pbRoad5_8.Location = new System.Drawing.Point(189, 525);
            this.pbRoad5_8.Name = "pbRoad5_8";
            this.pbRoad5_8.Size = new System.Drawing.Size(24, 85);
            this.pbRoad5_8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbRoad5_8.TabIndex = 75;
            this.pbRoad5_8.TabStop = false;
            this.pbRoad5_8.Tag = "road";
            this.pbRoad5_8.Click += new System.EventHandler(this.pbRoad5_8_Click);
            // 
            // pbRoad18_7
            // 
            this.pbRoad18_7.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.pbRoad18_7.Image = ((System.Drawing.Image)(resources.GetObject("pbRoad18_7.Image")));
            this.pbRoad18_7.Location = new System.Drawing.Point(692, 452);
            this.pbRoad18_7.Name = "pbRoad18_7";
            this.pbRoad18_7.Size = new System.Drawing.Size(24, 85);
            this.pbRoad18_7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbRoad18_7.TabIndex = 74;
            this.pbRoad18_7.TabStop = false;
            this.pbRoad18_7.Tag = "road";
            this.pbRoad18_7.Click += new System.EventHandler(this.pbRoad18_7_Click);
            // 
            // pbRoad3_8
            // 
            this.pbRoad3_8.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.pbRoad3_8.Image = ((System.Drawing.Image)(resources.GetObject("pbRoad3_8.Image")));
            this.pbRoad3_8.Location = new System.Drawing.Point(117, 525);
            this.pbRoad3_8.Name = "pbRoad3_8";
            this.pbRoad3_8.Size = new System.Drawing.Size(24, 85);
            this.pbRoad3_8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbRoad3_8.TabIndex = 73;
            this.pbRoad3_8.TabStop = false;
            this.pbRoad3_8.Tag = "road";
            this.pbRoad3_8.Click += new System.EventHandler(this.pbRoad3_8_Click);
            // 
            // pbRoad10_7
            // 
            this.pbRoad10_7.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.pbRoad10_7.Image = ((System.Drawing.Image)(resources.GetObject("pbRoad10_7.Image")));
            this.pbRoad10_7.Location = new System.Drawing.Point(385, 452);
            this.pbRoad10_7.Name = "pbRoad10_7";
            this.pbRoad10_7.Size = new System.Drawing.Size(24, 85);
            this.pbRoad10_7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbRoad10_7.TabIndex = 72;
            this.pbRoad10_7.TabStop = false;
            this.pbRoad10_7.Tag = "road";
            this.pbRoad10_7.Click += new System.EventHandler(this.pbRoad10_7_Click);
            // 
            // pbRoad6_7
            // 
            this.pbRoad6_7.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.pbRoad6_7.Image = ((System.Drawing.Image)(resources.GetObject("pbRoad6_7.Image")));
            this.pbRoad6_7.Location = new System.Drawing.Point(230, 452);
            this.pbRoad6_7.Name = "pbRoad6_7";
            this.pbRoad6_7.Size = new System.Drawing.Size(24, 85);
            this.pbRoad6_7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbRoad6_7.TabIndex = 71;
            this.pbRoad6_7.TabStop = false;
            this.pbRoad6_7.Tag = "road";
            this.pbRoad6_7.Click += new System.EventHandler(this.pbRoad6_7_Click);
            // 
            // pbRoad2_7
            // 
            this.pbRoad2_7.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.pbRoad2_7.Image = ((System.Drawing.Image)(resources.GetObject("pbRoad2_7.Image")));
            this.pbRoad2_7.Location = new System.Drawing.Point(69, 452);
            this.pbRoad2_7.Name = "pbRoad2_7";
            this.pbRoad2_7.Size = new System.Drawing.Size(24, 85);
            this.pbRoad2_7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbRoad2_7.TabIndex = 70;
            this.pbRoad2_7.TabStop = false;
            this.pbRoad2_7.Tag = "road";
            this.pbRoad2_7.Click += new System.EventHandler(this.pbRoad2_7_Click);
            // 
            // pbRoad19_6
            // 
            this.pbRoad19_6.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.pbRoad19_6.Image = ((System.Drawing.Image)(resources.GetObject("pbRoad19_6.Image")));
            this.pbRoad19_6.Location = new System.Drawing.Point(735, 375);
            this.pbRoad19_6.Name = "pbRoad19_6";
            this.pbRoad19_6.Size = new System.Drawing.Size(24, 85);
            this.pbRoad19_6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbRoad19_6.TabIndex = 69;
            this.pbRoad19_6.TabStop = false;
            this.pbRoad19_6.Tag = "road";
            this.pbRoad19_6.Click += new System.EventHandler(this.pbRoad19_6_Click);
            // 
            // pbRoad17_6
            // 
            this.pbRoad17_6.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.pbRoad17_6.Image = ((System.Drawing.Image)(resources.GetObject("pbRoad17_6.Image")));
            this.pbRoad17_6.Location = new System.Drawing.Point(662, 375);
            this.pbRoad17_6.Name = "pbRoad17_6";
            this.pbRoad17_6.Size = new System.Drawing.Size(24, 85);
            this.pbRoad17_6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbRoad17_6.TabIndex = 68;
            this.pbRoad17_6.TabStop = false;
            this.pbRoad17_6.Tag = "road";
            this.pbRoad17_6.Click += new System.EventHandler(this.pbRoad17_6_Click);
            // 
            // pbRoad15_6
            // 
            this.pbRoad15_6.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.pbRoad15_6.Image = ((System.Drawing.Image)(resources.GetObject("pbRoad15_6.Image")));
            this.pbRoad15_6.Location = new System.Drawing.Point(581, 375);
            this.pbRoad15_6.Name = "pbRoad15_6";
            this.pbRoad15_6.Size = new System.Drawing.Size(24, 85);
            this.pbRoad15_6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbRoad15_6.TabIndex = 67;
            this.pbRoad15_6.TabStop = false;
            this.pbRoad15_6.Tag = "road";
            this.pbRoad15_6.Click += new System.EventHandler(this.pbRoad15_6_Click);
            // 
            // pbRoad13_6
            // 
            this.pbRoad13_6.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.pbRoad13_6.Image = ((System.Drawing.Image)(resources.GetObject("pbRoad13_6.Image")));
            this.pbRoad13_6.Location = new System.Drawing.Point(505, 375);
            this.pbRoad13_6.Name = "pbRoad13_6";
            this.pbRoad13_6.Size = new System.Drawing.Size(24, 85);
            this.pbRoad13_6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbRoad13_6.TabIndex = 66;
            this.pbRoad13_6.TabStop = false;
            this.pbRoad13_6.Tag = "road";
            this.pbRoad13_6.Click += new System.EventHandler(this.pbRoad13_6_Click);
            // 
            // pbRoad14_7
            // 
            this.pbRoad14_7.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.pbRoad14_7.Image = ((System.Drawing.Image)(resources.GetObject("pbRoad14_7.Image")));
            this.pbRoad14_7.Location = new System.Drawing.Point(535, 452);
            this.pbRoad14_7.Name = "pbRoad14_7";
            this.pbRoad14_7.Size = new System.Drawing.Size(24, 85);
            this.pbRoad14_7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbRoad14_7.TabIndex = 65;
            this.pbRoad14_7.TabStop = false;
            this.pbRoad14_7.Tag = "road";
            this.pbRoad14_7.Click += new System.EventHandler(this.pbRoad14_7_Click);
            // 
            // pbRoad19_4
            // 
            this.pbRoad19_4.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.pbRoad19_4.Image = ((System.Drawing.Image)(resources.GetObject("pbRoad19_4.Image")));
            this.pbRoad19_4.Location = new System.Drawing.Point(735, 254);
            this.pbRoad19_4.Name = "pbRoad19_4";
            this.pbRoad19_4.Size = new System.Drawing.Size(24, 85);
            this.pbRoad19_4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbRoad19_4.TabIndex = 64;
            this.pbRoad19_4.TabStop = false;
            this.pbRoad19_4.Tag = "road";
            this.pbRoad19_4.Click += new System.EventHandler(this.pbRoad19_4_Click);
            // 
            // pbRoad20_5
            // 
            this.pbRoad20_5.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.pbRoad20_5.Image = ((System.Drawing.Image)(resources.GetObject("pbRoad20_5.Image")));
            this.pbRoad20_5.Location = new System.Drawing.Point(765, 319);
            this.pbRoad20_5.Name = "pbRoad20_5";
            this.pbRoad20_5.Size = new System.Drawing.Size(24, 85);
            this.pbRoad20_5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbRoad20_5.TabIndex = 63;
            this.pbRoad20_5.TabStop = false;
            this.pbRoad20_5.Tag = "road";
            this.pbRoad20_5.Click += new System.EventHandler(this.pbRoad20_5_Click);
            // 
            // pbRoad16_5
            // 
            this.pbRoad16_5.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.pbRoad16_5.Image = ((System.Drawing.Image)(resources.GetObject("pbRoad16_5.Image")));
            this.pbRoad16_5.Location = new System.Drawing.Point(611, 319);
            this.pbRoad16_5.Name = "pbRoad16_5";
            this.pbRoad16_5.Size = new System.Drawing.Size(24, 85);
            this.pbRoad16_5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbRoad16_5.TabIndex = 62;
            this.pbRoad16_5.TabStop = false;
            this.pbRoad16_5.Tag = "road";
            this.pbRoad16_5.Click += new System.EventHandler(this.pbRoad16_5_Click);
            // 
            // pbRoad12_5
            // 
            this.pbRoad12_5.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.pbRoad12_5.Image = ((System.Drawing.Image)(resources.GetObject("pbRoad12_5.Image")));
            this.pbRoad12_5.Location = new System.Drawing.Point(464, 319);
            this.pbRoad12_5.Name = "pbRoad12_5";
            this.pbRoad12_5.Size = new System.Drawing.Size(24, 85);
            this.pbRoad12_5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbRoad12_5.TabIndex = 61;
            this.pbRoad12_5.TabStop = false;
            this.pbRoad12_5.Tag = "road";
            this.pbRoad12_5.Click += new System.EventHandler(this.pbRoad12_5_Click);
            // 
            // pbRoad9_6
            // 
            this.pbRoad9_6.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.pbRoad9_6.Image = ((System.Drawing.Image)(resources.GetObject("pbRoad9_6.Image")));
            this.pbRoad9_6.Location = new System.Drawing.Point(345, 375);
            this.pbRoad9_6.Name = "pbRoad9_6";
            this.pbRoad9_6.Size = new System.Drawing.Size(24, 85);
            this.pbRoad9_6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbRoad9_6.TabIndex = 60;
            this.pbRoad9_6.TabStop = false;
            this.pbRoad9_6.Tag = "road";
            this.pbRoad9_6.Click += new System.EventHandler(this.pbRoad9_6_Click);
            // 
            // pbRoad8_5
            // 
            this.pbRoad8_5.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.pbRoad8_5.Image = ((System.Drawing.Image)(resources.GetObject("pbRoad8_5.Image")));
            this.pbRoad8_5.Location = new System.Drawing.Point(299, 319);
            this.pbRoad8_5.Name = "pbRoad8_5";
            this.pbRoad8_5.Size = new System.Drawing.Size(24, 85);
            this.pbRoad8_5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbRoad8_5.TabIndex = 59;
            this.pbRoad8_5.TabStop = false;
            this.pbRoad8_5.Tag = "road";
            this.pbRoad8_5.Click += new System.EventHandler(this.pbRoad8_5_Click);
            // 
            // pbRoad7_6
            // 
            this.pbRoad7_6.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.pbRoad7_6.Image = ((System.Drawing.Image)(resources.GetObject("pbRoad7_6.Image")));
            this.pbRoad7_6.Location = new System.Drawing.Point(269, 375);
            this.pbRoad7_6.Name = "pbRoad7_6";
            this.pbRoad7_6.Size = new System.Drawing.Size(24, 85);
            this.pbRoad7_6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbRoad7_6.TabIndex = 58;
            this.pbRoad7_6.TabStop = false;
            this.pbRoad7_6.Tag = "road";
            this.pbRoad7_6.Click += new System.EventHandler(this.pbRoad7_6_Click);
            // 
            // pbRoad5_6
            // 
            this.pbRoad5_6.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.pbRoad5_6.Image = ((System.Drawing.Image)(resources.GetObject("pbRoad5_6.Image")));
            this.pbRoad5_6.Location = new System.Drawing.Point(189, 375);
            this.pbRoad5_6.Name = "pbRoad5_6";
            this.pbRoad5_6.Size = new System.Drawing.Size(24, 85);
            this.pbRoad5_6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbRoad5_6.TabIndex = 57;
            this.pbRoad5_6.TabStop = false;
            this.pbRoad5_6.Tag = "road";
            this.pbRoad5_6.Click += new System.EventHandler(this.pbRoad5_6_Click);
            // 
            // pbRoad3_6
            // 
            this.pbRoad3_6.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.pbRoad3_6.Image = ((System.Drawing.Image)(resources.GetObject("pbRoad3_6.Image")));
            this.pbRoad3_6.Location = new System.Drawing.Point(117, 375);
            this.pbRoad3_6.Name = "pbRoad3_6";
            this.pbRoad3_6.Size = new System.Drawing.Size(24, 85);
            this.pbRoad3_6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbRoad3_6.TabIndex = 56;
            this.pbRoad3_6.TabStop = false;
            this.pbRoad3_6.Tag = "road";
            this.pbRoad3_6.Click += new System.EventHandler(this.pbRoad3_6_Click);
            // 
            // pbRoad1_6
            // 
            this.pbRoad1_6.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.pbRoad1_6.Image = ((System.Drawing.Image)(resources.GetObject("pbRoad1_6.Image")));
            this.pbRoad1_6.Location = new System.Drawing.Point(30, 375);
            this.pbRoad1_6.Name = "pbRoad1_6";
            this.pbRoad1_6.Size = new System.Drawing.Size(24, 85);
            this.pbRoad1_6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbRoad1_6.TabIndex = 55;
            this.pbRoad1_6.TabStop = false;
            this.pbRoad1_6.Tag = "road";
            this.pbRoad1_6.Click += new System.EventHandler(this.pbRoad1_6_Click);
            // 
            // pbRoad4_5
            // 
            this.pbRoad4_5.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.pbRoad4_5.Image = ((System.Drawing.Image)(resources.GetObject("pbRoad4_5.Image")));
            this.pbRoad4_5.Location = new System.Drawing.Point(147, 319);
            this.pbRoad4_5.Name = "pbRoad4_5";
            this.pbRoad4_5.Size = new System.Drawing.Size(24, 85);
            this.pbRoad4_5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbRoad4_5.TabIndex = 54;
            this.pbRoad4_5.TabStop = false;
            this.pbRoad4_5.Tag = "road";
            this.pbRoad4_5.Click += new System.EventHandler(this.pbRoad4_5_Click);
            // 
            // pbRoad0_5
            // 
            this.pbRoad0_5.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.pbRoad0_5.Image = ((System.Drawing.Image)(resources.GetObject("pbRoad0_5.Image")));
            this.pbRoad0_5.Location = new System.Drawing.Point(0, 319);
            this.pbRoad0_5.Name = "pbRoad0_5";
            this.pbRoad0_5.Size = new System.Drawing.Size(24, 85);
            this.pbRoad0_5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbRoad0_5.TabIndex = 53;
            this.pbRoad0_5.TabStop = false;
            this.pbRoad0_5.Tag = "road";
            this.pbRoad0_5.Click += new System.EventHandler(this.pbRoad0_5_Click);
            // 
            // pbRoad1_4
            // 
            this.pbRoad1_4.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.pbRoad1_4.Image = ((System.Drawing.Image)(resources.GetObject("pbRoad1_4.Image")));
            this.pbRoad1_4.Location = new System.Drawing.Point(30, 248);
            this.pbRoad1_4.Name = "pbRoad1_4";
            this.pbRoad1_4.Size = new System.Drawing.Size(24, 85);
            this.pbRoad1_4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbRoad1_4.TabIndex = 52;
            this.pbRoad1_4.TabStop = false;
            this.pbRoad1_4.Tag = "road";
            this.pbRoad1_4.Click += new System.EventHandler(this.pbRoad1_4_Click);
            // 
            // pbRoad13_4
            // 
            this.pbRoad13_4.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.pbRoad13_4.Image = ((System.Drawing.Image)(resources.GetObject("pbRoad13_4.Image")));
            this.pbRoad13_4.Location = new System.Drawing.Point(505, 254);
            this.pbRoad13_4.Name = "pbRoad13_4";
            this.pbRoad13_4.Size = new System.Drawing.Size(24, 85);
            this.pbRoad13_4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbRoad13_4.TabIndex = 51;
            this.pbRoad13_4.TabStop = false;
            this.pbRoad13_4.Tag = "road";
            this.pbRoad13_4.Click += new System.EventHandler(this.pbRoad13_4_Click);
            // 
            // pbRoad15_4
            // 
            this.pbRoad15_4.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.pbRoad15_4.Image = ((System.Drawing.Image)(resources.GetObject("pbRoad15_4.Image")));
            this.pbRoad15_4.Location = new System.Drawing.Point(581, 254);
            this.pbRoad15_4.Name = "pbRoad15_4";
            this.pbRoad15_4.Size = new System.Drawing.Size(24, 85);
            this.pbRoad15_4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbRoad15_4.TabIndex = 50;
            this.pbRoad15_4.TabStop = false;
            this.pbRoad15_4.Tag = "road";
            this.pbRoad15_4.Click += new System.EventHandler(this.pbRoad15_4_Click);
            // 
            // pbRoad17_4
            // 
            this.pbRoad17_4.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.pbRoad17_4.Image = ((System.Drawing.Image)(resources.GetObject("pbRoad17_4.Image")));
            this.pbRoad17_4.Location = new System.Drawing.Point(662, 254);
            this.pbRoad17_4.Name = "pbRoad17_4";
            this.pbRoad17_4.Size = new System.Drawing.Size(24, 85);
            this.pbRoad17_4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbRoad17_4.TabIndex = 49;
            this.pbRoad17_4.TabStop = false;
            this.pbRoad17_4.Tag = "road";
            this.pbRoad17_4.Click += new System.EventHandler(this.pbRoad17_4_Click);
            // 
            // pbRoad17_2
            // 
            this.pbRoad17_2.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.pbRoad17_2.Image = ((System.Drawing.Image)(resources.GetObject("pbRoad17_2.Image")));
            this.pbRoad17_2.Location = new System.Drawing.Point(662, 108);
            this.pbRoad17_2.Name = "pbRoad17_2";
            this.pbRoad17_2.Size = new System.Drawing.Size(24, 85);
            this.pbRoad17_2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbRoad17_2.TabIndex = 48;
            this.pbRoad17_2.TabStop = false;
            this.pbRoad17_2.Tag = "road";
            this.pbRoad17_2.Click += new System.EventHandler(this.pbRoad17_2_Click);
            // 
            // pbRoad18_3
            // 
            this.pbRoad18_3.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.pbRoad18_3.Image = ((System.Drawing.Image)(resources.GetObject("pbRoad18_3.Image")));
            this.pbRoad18_3.Location = new System.Drawing.Point(692, 186);
            this.pbRoad18_3.Name = "pbRoad18_3";
            this.pbRoad18_3.Size = new System.Drawing.Size(24, 85);
            this.pbRoad18_3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbRoad18_3.TabIndex = 47;
            this.pbRoad18_3.TabStop = false;
            this.pbRoad18_3.Tag = "road";
            this.pbRoad18_3.Click += new System.EventHandler(this.pbRoad18_3_Click);
            // 
            // pbRoad14_3
            // 
            this.pbRoad14_3.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.pbRoad14_3.Image = ((System.Drawing.Image)(resources.GetObject("pbRoad14_3.Image")));
            this.pbRoad14_3.Location = new System.Drawing.Point(535, 186);
            this.pbRoad14_3.Name = "pbRoad14_3";
            this.pbRoad14_3.Size = new System.Drawing.Size(24, 85);
            this.pbRoad14_3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbRoad14_3.TabIndex = 46;
            this.pbRoad14_3.TabStop = false;
            this.pbRoad14_3.Tag = "road";
            this.pbRoad14_3.Click += new System.EventHandler(this.pbRoad14_3_Click);
            // 
            // pbRoad11_4
            // 
            this.pbRoad11_4.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.pbRoad11_4.Image = ((System.Drawing.Image)(resources.GetObject("pbRoad11_4.Image")));
            this.pbRoad11_4.Location = new System.Drawing.Point(425, 254);
            this.pbRoad11_4.Name = "pbRoad11_4";
            this.pbRoad11_4.Size = new System.Drawing.Size(24, 85);
            this.pbRoad11_4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbRoad11_4.TabIndex = 45;
            this.pbRoad11_4.TabStop = false;
            this.pbRoad11_4.Tag = "road";
            this.pbRoad11_4.Click += new System.EventHandler(this.pbRoad11_4_Click);
            // 
            // pbRoad7_4
            // 
            this.pbRoad7_4.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.pbRoad7_4.Image = ((System.Drawing.Image)(resources.GetObject("pbRoad7_4.Image")));
            this.pbRoad7_4.Location = new System.Drawing.Point(269, 248);
            this.pbRoad7_4.Name = "pbRoad7_4";
            this.pbRoad7_4.Size = new System.Drawing.Size(24, 85);
            this.pbRoad7_4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbRoad7_4.TabIndex = 44;
            this.pbRoad7_4.TabStop = false;
            this.pbRoad7_4.Tag = "road";
            this.pbRoad7_4.Click += new System.EventHandler(this.pbRoad7_4_Click);
            // 
            // pbRoad9_4
            // 
            this.pbRoad9_4.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.pbRoad9_4.Image = ((System.Drawing.Image)(resources.GetObject("pbRoad9_4.Image")));
            this.pbRoad9_4.Location = new System.Drawing.Point(345, 248);
            this.pbRoad9_4.Name = "pbRoad9_4";
            this.pbRoad9_4.Size = new System.Drawing.Size(24, 85);
            this.pbRoad9_4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbRoad9_4.TabIndex = 43;
            this.pbRoad9_4.TabStop = false;
            this.pbRoad9_4.Tag = "road";
            this.pbRoad9_4.Click += new System.EventHandler(this.pbRoad9_4_Click);
            // 
            // pbRoad10_3
            // 
            this.pbRoad10_3.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.pbRoad10_3.Image = ((System.Drawing.Image)(resources.GetObject("pbRoad10_3.Image")));
            this.pbRoad10_3.Location = new System.Drawing.Point(385, 186);
            this.pbRoad10_3.Name = "pbRoad10_3";
            this.pbRoad10_3.Size = new System.Drawing.Size(24, 85);
            this.pbRoad10_3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbRoad10_3.TabIndex = 42;
            this.pbRoad10_3.TabStop = false;
            this.pbRoad10_3.Tag = "road";
            this.pbRoad10_3.Click += new System.EventHandler(this.pbRoad10_3_Click);
            // 
            // pbRoad2_3
            // 
            this.pbRoad2_3.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.pbRoad2_3.Image = ((System.Drawing.Image)(resources.GetObject("pbRoad2_3.Image")));
            this.pbRoad2_3.Location = new System.Drawing.Point(69, 186);
            this.pbRoad2_3.Name = "pbRoad2_3";
            this.pbRoad2_3.Size = new System.Drawing.Size(24, 85);
            this.pbRoad2_3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbRoad2_3.TabIndex = 41;
            this.pbRoad2_3.TabStop = false;
            this.pbRoad2_3.Tag = "road";
            this.pbRoad2_3.Click += new System.EventHandler(this.pbRoad2_3_Click);
            // 
            // pbRoad3_4
            // 
            this.pbRoad3_4.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.pbRoad3_4.Image = ((System.Drawing.Image)(resources.GetObject("pbRoad3_4.Image")));
            this.pbRoad3_4.Location = new System.Drawing.Point(117, 248);
            this.pbRoad3_4.Name = "pbRoad3_4";
            this.pbRoad3_4.Size = new System.Drawing.Size(24, 85);
            this.pbRoad3_4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbRoad3_4.TabIndex = 40;
            this.pbRoad3_4.TabStop = false;
            this.pbRoad3_4.Tag = "road";
            this.pbRoad3_4.Click += new System.EventHandler(this.pbRoad3_4_Click);
            // 
            // pbRoad5_4
            // 
            this.pbRoad5_4.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.pbRoad5_4.Image = ((System.Drawing.Image)(resources.GetObject("pbRoad5_4.Image")));
            this.pbRoad5_4.Location = new System.Drawing.Point(189, 248);
            this.pbRoad5_4.Name = "pbRoad5_4";
            this.pbRoad5_4.Size = new System.Drawing.Size(24, 85);
            this.pbRoad5_4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbRoad5_4.TabIndex = 39;
            this.pbRoad5_4.TabStop = false;
            this.pbRoad5_4.Tag = "road";
            this.pbRoad5_4.Click += new System.EventHandler(this.pbRoad5_4_Click);
            // 
            // pbRoad6_3
            // 
            this.pbRoad6_3.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.pbRoad6_3.Image = ((System.Drawing.Image)(resources.GetObject("pbRoad6_3.Image")));
            this.pbRoad6_3.Location = new System.Drawing.Point(230, 186);
            this.pbRoad6_3.Name = "pbRoad6_3";
            this.pbRoad6_3.Size = new System.Drawing.Size(24, 85);
            this.pbRoad6_3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbRoad6_3.TabIndex = 38;
            this.pbRoad6_3.TabStop = false;
            this.pbRoad6_3.Tag = "road";
            this.pbRoad6_3.Click += new System.EventHandler(this.pbRoad6_3_Click);
            // 
            // pbRoad3_2
            // 
            this.pbRoad3_2.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.pbRoad3_2.Image = ((System.Drawing.Image)(resources.GetObject("pbRoad3_2.Image")));
            this.pbRoad3_2.Location = new System.Drawing.Point(117, 108);
            this.pbRoad3_2.Name = "pbRoad3_2";
            this.pbRoad3_2.Size = new System.Drawing.Size(24, 85);
            this.pbRoad3_2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbRoad3_2.TabIndex = 37;
            this.pbRoad3_2.TabStop = false;
            this.pbRoad3_2.Tag = "road";
            this.pbRoad3_2.Click += new System.EventHandler(this.pbRoad3_2_Click);
            // 
            // pbRoad13_0
            // 
            this.pbRoad13_0.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.pbRoad13_0.Image = ((System.Drawing.Image)(resources.GetObject("pbRoad13_0.Image")));
            this.pbRoad13_0.Location = new System.Drawing.Point(505, -10);
            this.pbRoad13_0.Name = "pbRoad13_0";
            this.pbRoad13_0.Size = new System.Drawing.Size(24, 85);
            this.pbRoad13_0.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbRoad13_0.TabIndex = 36;
            this.pbRoad13_0.TabStop = false;
            this.pbRoad13_0.Tag = "road";
            this.pbRoad13_0.Click += new System.EventHandler(this.pbRoad13_0_Click);
            // 
            // pbRoad13_2
            // 
            this.pbRoad13_2.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.pbRoad13_2.Image = ((System.Drawing.Image)(resources.GetObject("pbRoad13_2.Image")));
            this.pbRoad13_2.Location = new System.Drawing.Point(505, 108);
            this.pbRoad13_2.Name = "pbRoad13_2";
            this.pbRoad13_2.Size = new System.Drawing.Size(24, 85);
            this.pbRoad13_2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbRoad13_2.TabIndex = 35;
            this.pbRoad13_2.TabStop = false;
            this.pbRoad13_2.Tag = "road";
            this.pbRoad13_2.Click += new System.EventHandler(this.pbRoad13_2_Click);
            // 
            // pbRoad15_2
            // 
            this.pbRoad15_2.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.pbRoad15_2.Image = ((System.Drawing.Image)(resources.GetObject("pbRoad15_2.Image")));
            this.pbRoad15_2.Location = new System.Drawing.Point(581, 108);
            this.pbRoad15_2.Name = "pbRoad15_2";
            this.pbRoad15_2.Size = new System.Drawing.Size(24, 85);
            this.pbRoad15_2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbRoad15_2.TabIndex = 34;
            this.pbRoad15_2.TabStop = false;
            this.pbRoad15_2.Tag = "road";
            this.pbRoad15_2.Click += new System.EventHandler(this.pbRoad15_2_Click);
            // 
            // pbRoad16_1
            // 
            this.pbRoad16_1.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.pbRoad16_1.Image = ((System.Drawing.Image)(resources.GetObject("pbRoad16_1.Image")));
            this.pbRoad16_1.Location = new System.Drawing.Point(611, 51);
            this.pbRoad16_1.Name = "pbRoad16_1";
            this.pbRoad16_1.Size = new System.Drawing.Size(24, 85);
            this.pbRoad16_1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbRoad16_1.TabIndex = 33;
            this.pbRoad16_1.TabStop = false;
            this.pbRoad16_1.Tag = "road";
            this.pbRoad16_1.Click += new System.EventHandler(this.pbRoad16_1_Click);
            // 
            // pbRoad15_0
            // 
            this.pbRoad15_0.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.pbRoad15_0.Image = ((System.Drawing.Image)(resources.GetObject("pbRoad15_0.Image")));
            this.pbRoad15_0.Location = new System.Drawing.Point(581, -10);
            this.pbRoad15_0.Name = "pbRoad15_0";
            this.pbRoad15_0.Size = new System.Drawing.Size(24, 85);
            this.pbRoad15_0.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbRoad15_0.TabIndex = 32;
            this.pbRoad15_0.TabStop = false;
            this.pbRoad15_0.Tag = "road";
            this.pbRoad15_0.Click += new System.EventHandler(this.pbRoad15_0_Click);
            // 
            // pbRoad9_0
            // 
            this.pbRoad9_0.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.pbRoad9_0.Image = ((System.Drawing.Image)(resources.GetObject("pbRoad9_0.Image")));
            this.pbRoad9_0.Location = new System.Drawing.Point(345, -10);
            this.pbRoad9_0.Name = "pbRoad9_0";
            this.pbRoad9_0.Size = new System.Drawing.Size(24, 85);
            this.pbRoad9_0.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbRoad9_0.TabIndex = 31;
            this.pbRoad9_0.TabStop = false;
            this.pbRoad9_0.Tag = "road";
            this.pbRoad9_0.Click += new System.EventHandler(this.pbRoad9_0_Click);
            // 
            // pbRoad9_2
            // 
            this.pbRoad9_2.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.pbRoad9_2.Image = ((System.Drawing.Image)(resources.GetObject("pbRoad9_2.Image")));
            this.pbRoad9_2.Location = new System.Drawing.Point(345, 108);
            this.pbRoad9_2.Name = "pbRoad9_2";
            this.pbRoad9_2.Size = new System.Drawing.Size(24, 85);
            this.pbRoad9_2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbRoad9_2.TabIndex = 30;
            this.pbRoad9_2.TabStop = false;
            this.pbRoad9_2.Tag = "road";
            this.pbRoad9_2.Click += new System.EventHandler(this.pbRoad9_2_Click);
            // 
            // pbRoad11_2
            // 
            this.pbRoad11_2.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.pbRoad11_2.Image = ((System.Drawing.Image)(resources.GetObject("pbRoad11_2.Image")));
            this.pbRoad11_2.Location = new System.Drawing.Point(425, 108);
            this.pbRoad11_2.Name = "pbRoad11_2";
            this.pbRoad11_2.Size = new System.Drawing.Size(24, 85);
            this.pbRoad11_2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbRoad11_2.TabIndex = 29;
            this.pbRoad11_2.TabStop = false;
            this.pbRoad11_2.Tag = "road";
            this.pbRoad11_2.Click += new System.EventHandler(this.pbRoad11_2_Click);
            // 
            // pbRoad12_1
            // 
            this.pbRoad12_1.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.pbRoad12_1.Image = ((System.Drawing.Image)(resources.GetObject("pbRoad12_1.Image")));
            this.pbRoad12_1.Location = new System.Drawing.Point(464, 51);
            this.pbRoad12_1.Name = "pbRoad12_1";
            this.pbRoad12_1.Size = new System.Drawing.Size(24, 85);
            this.pbRoad12_1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbRoad12_1.TabIndex = 28;
            this.pbRoad12_1.TabStop = false;
            this.pbRoad12_1.Tag = "road";
            this.pbRoad12_1.Click += new System.EventHandler(this.pbRoad12_1_Click);
            // 
            // pbRoad11_0
            // 
            this.pbRoad11_0.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.pbRoad11_0.Image = ((System.Drawing.Image)(resources.GetObject("pbRoad11_0.Image")));
            this.pbRoad11_0.Location = new System.Drawing.Point(425, -10);
            this.pbRoad11_0.Name = "pbRoad11_0";
            this.pbRoad11_0.Size = new System.Drawing.Size(24, 85);
            this.pbRoad11_0.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbRoad11_0.TabIndex = 27;
            this.pbRoad11_0.TabStop = false;
            this.pbRoad11_0.Tag = "road";
            this.pbRoad11_0.Click += new System.EventHandler(this.pbRoad11_0_Click);
            // 
            // pbRoad5_0
            // 
            this.pbRoad5_0.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.pbRoad5_0.Image = ((System.Drawing.Image)(resources.GetObject("pbRoad5_0.Image")));
            this.pbRoad5_0.Location = new System.Drawing.Point(189, -10);
            this.pbRoad5_0.Name = "pbRoad5_0";
            this.pbRoad5_0.Size = new System.Drawing.Size(24, 85);
            this.pbRoad5_0.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbRoad5_0.TabIndex = 26;
            this.pbRoad5_0.TabStop = false;
            this.pbRoad5_0.Tag = "road";
            this.pbRoad5_0.Click += new System.EventHandler(this.pbRoad5_0_Click);
            // 
            // pbRoad4_1
            // 
            this.pbRoad4_1.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.pbRoad4_1.Image = ((System.Drawing.Image)(resources.GetObject("pbRoad4_1.Image")));
            this.pbRoad4_1.Location = new System.Drawing.Point(147, 51);
            this.pbRoad4_1.Name = "pbRoad4_1";
            this.pbRoad4_1.Size = new System.Drawing.Size(24, 85);
            this.pbRoad4_1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbRoad4_1.TabIndex = 25;
            this.pbRoad4_1.TabStop = false;
            this.pbRoad4_1.Tag = "road";
            this.pbRoad4_1.Click += new System.EventHandler(this.pbRoad4_1_Click);
            // 
            // pbRoad5_2
            // 
            this.pbRoad5_2.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.pbRoad5_2.Image = ((System.Drawing.Image)(resources.GetObject("pbRoad5_2.Image")));
            this.pbRoad5_2.Location = new System.Drawing.Point(189, 108);
            this.pbRoad5_2.Name = "pbRoad5_2";
            this.pbRoad5_2.Size = new System.Drawing.Size(24, 85);
            this.pbRoad5_2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbRoad5_2.TabIndex = 24;
            this.pbRoad5_2.TabStop = false;
            this.pbRoad5_2.Tag = "road";
            this.pbRoad5_2.Click += new System.EventHandler(this.pbRoad5_2_Click);
            // 
            // pbRoad7_2
            // 
            this.pbRoad7_2.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.pbRoad7_2.Image = ((System.Drawing.Image)(resources.GetObject("pbRoad7_2.Image")));
            this.pbRoad7_2.Location = new System.Drawing.Point(269, 108);
            this.pbRoad7_2.Name = "pbRoad7_2";
            this.pbRoad7_2.Size = new System.Drawing.Size(24, 85);
            this.pbRoad7_2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbRoad7_2.TabIndex = 23;
            this.pbRoad7_2.TabStop = false;
            this.pbRoad7_2.Tag = "road";
            this.pbRoad7_2.Click += new System.EventHandler(this.pbRoad7_2_Click);
            // 
            // pbRoad8_1
            // 
            this.pbRoad8_1.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.pbRoad8_1.Image = ((System.Drawing.Image)(resources.GetObject("pbRoad8_1.Image")));
            this.pbRoad8_1.Location = new System.Drawing.Point(299, 51);
            this.pbRoad8_1.Name = "pbRoad8_1";
            this.pbRoad8_1.Size = new System.Drawing.Size(24, 85);
            this.pbRoad8_1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbRoad8_1.TabIndex = 22;
            this.pbRoad8_1.TabStop = false;
            this.pbRoad8_1.Tag = "road";
            this.pbRoad8_1.Click += new System.EventHandler(this.pbRoad8_1_Click);
            // 
            // pbLandTile14_9
            // 
            this.pbLandTile14_9.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.pbLandTile14_9.Image = global::OrangeCatans.Properties.Resources.baseLand;
            this.pbLandTile14_9.Location = new System.Drawing.Point(474, 550);
            this.pbLandTile14_9.Name = "pbLandTile14_9";
            this.pbLandTile14_9.Size = new System.Drawing.Size(150, 171);
            this.pbLandTile14_9.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbLandTile14_9.TabIndex = 21;
            this.pbLandTile14_9.TabStop = false;
            this.pbLandTile14_9.Tag = "land";
            this.pbLandTile14_9.Click += new System.EventHandler(this.pbLandTile14_9_Click);
            // 
            // pbRoad7_0
            // 
            this.pbRoad7_0.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.pbRoad7_0.Image = ((System.Drawing.Image)(resources.GetObject("pbRoad7_0.Image")));
            this.pbRoad7_0.Location = new System.Drawing.Point(269, -10);
            this.pbRoad7_0.Name = "pbRoad7_0";
            this.pbRoad7_0.Size = new System.Drawing.Size(24, 85);
            this.pbRoad7_0.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbRoad7_0.TabIndex = 20;
            this.pbRoad7_0.TabStop = false;
            this.pbRoad7_0.Tag = "road";
            this.pbRoad7_0.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // pbLandTile10_9
            // 
            this.pbLandTile10_9.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.pbLandTile10_9.Image = global::OrangeCatans.Properties.Resources.baseLand;
            this.pbLandTile10_9.Location = new System.Drawing.Point(318, 550);
            this.pbLandTile10_9.Name = "pbLandTile10_9";
            this.pbLandTile10_9.Size = new System.Drawing.Size(150, 171);
            this.pbLandTile10_9.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbLandTile10_9.TabIndex = 13;
            this.pbLandTile10_9.TabStop = false;
            this.pbLandTile10_9.Tag = "land";
            this.pbLandTile10_9.Click += new System.EventHandler(this.pbLandTile10_9_Click);
            // 
            // pbLandTile16_7
            // 
            this.pbLandTile16_7.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.pbLandTile16_7.Image = global::OrangeCatans.Properties.Resources.baseLand;
            this.pbLandTile16_7.Location = new System.Drawing.Point(553, 414);
            this.pbLandTile16_7.Name = "pbLandTile16_7";
            this.pbLandTile16_7.Size = new System.Drawing.Size(150, 171);
            this.pbLandTile16_7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbLandTile16_7.TabIndex = 18;
            this.pbLandTile16_7.TabStop = false;
            this.pbLandTile16_7.Tag = "land";
            this.pbLandTile16_7.Click += new System.EventHandler(this.pbLandTile16_7_Click);
            // 
            // pbLandTile12_7
            // 
            this.pbLandTile12_7.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.pbLandTile12_7.Image = global::OrangeCatans.Properties.Resources.baseLand;
            this.pbLandTile12_7.Location = new System.Drawing.Point(397, 414);
            this.pbLandTile12_7.Name = "pbLandTile12_7";
            this.pbLandTile12_7.Size = new System.Drawing.Size(150, 171);
            this.pbLandTile12_7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbLandTile12_7.TabIndex = 11;
            this.pbLandTile12_7.TabStop = false;
            this.pbLandTile12_7.Tag = "land";
            this.pbLandTile12_7.Click += new System.EventHandler(this.pbLandTile12_7_Click);
            // 
            // pbLandTile18_5
            // 
            this.pbLandTile18_5.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.pbLandTile18_5.Image = global::OrangeCatans.Properties.Resources.baseLand;
            this.pbLandTile18_5.Location = new System.Drawing.Point(630, 275);
            this.pbLandTile18_5.Name = "pbLandTile18_5";
            this.pbLandTile18_5.Size = new System.Drawing.Size(150, 171);
            this.pbLandTile18_5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbLandTile18_5.TabIndex = 16;
            this.pbLandTile18_5.TabStop = false;
            this.pbLandTile18_5.Tag = "land";
            this.pbLandTile18_5.Click += new System.EventHandler(this.pbLandTile18_5_Click);
            // 
            // pbLandTile14_5
            // 
            this.pbLandTile14_5.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.pbLandTile14_5.Image = global::OrangeCatans.Properties.Resources.baseLand;
            this.pbLandTile14_5.Location = new System.Drawing.Point(474, 275);
            this.pbLandTile14_5.Name = "pbLandTile14_5";
            this.pbLandTile14_5.Size = new System.Drawing.Size(150, 171);
            this.pbLandTile14_5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbLandTile14_5.TabIndex = 15;
            this.pbLandTile14_5.TabStop = false;
            this.pbLandTile14_5.Tag = "land";
            this.pbLandTile14_5.Click += new System.EventHandler(this.pbLandTile14_5_Click);
            // 
            // pbLandTile16_3
            // 
            this.pbLandTile16_3.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.pbLandTile16_3.Image = global::OrangeCatans.Properties.Resources.baseLand;
            this.pbLandTile16_3.Location = new System.Drawing.Point(553, 142);
            this.pbLandTile16_3.Name = "pbLandTile16_3";
            this.pbLandTile16_3.Size = new System.Drawing.Size(150, 171);
            this.pbLandTile16_3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbLandTile16_3.TabIndex = 17;
            this.pbLandTile16_3.TabStop = false;
            this.pbLandTile16_3.Tag = "land";
            this.pbLandTile16_3.Click += new System.EventHandler(this.pbLandTile16_3_Click);
            // 
            // pbLandTile6_9
            // 
            this.pbLandTile6_9.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.pbLandTile6_9.Image = global::OrangeCatans.Properties.Resources.baseLand;
            this.pbLandTile6_9.Location = new System.Drawing.Point(162, 550);
            this.pbLandTile6_9.Name = "pbLandTile6_9";
            this.pbLandTile6_9.Size = new System.Drawing.Size(150, 171);
            this.pbLandTile6_9.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbLandTile6_9.TabIndex = 12;
            this.pbLandTile6_9.TabStop = false;
            this.pbLandTile6_9.Tag = "land";
            this.pbLandTile6_9.Click += new System.EventHandler(this.pbLandTile6_9_Click);
            // 
            // pbLandTile8_7
            // 
            this.pbLandTile8_7.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.pbLandTile8_7.Image = global::OrangeCatans.Properties.Resources.baseLand;
            this.pbLandTile8_7.Location = new System.Drawing.Point(241, 414);
            this.pbLandTile8_7.Name = "pbLandTile8_7";
            this.pbLandTile8_7.Size = new System.Drawing.Size(150, 171);
            this.pbLandTile8_7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbLandTile8_7.TabIndex = 10;
            this.pbLandTile8_7.TabStop = false;
            this.pbLandTile8_7.Tag = "land";
            this.pbLandTile8_7.Click += new System.EventHandler(this.pbLandTile8_7_Click);
            // 
            // pbLandTile4_7
            // 
            this.pbLandTile4_7.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.pbLandTile4_7.Image = global::OrangeCatans.Properties.Resources.baseLand;
            this.pbLandTile4_7.Location = new System.Drawing.Point(85, 414);
            this.pbLandTile4_7.Name = "pbLandTile4_7";
            this.pbLandTile4_7.Size = new System.Drawing.Size(150, 171);
            this.pbLandTile4_7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbLandTile4_7.TabIndex = 9;
            this.pbLandTile4_7.TabStop = false;
            this.pbLandTile4_7.Tag = "land";
            this.pbLandTile4_7.Click += new System.EventHandler(this.pbLandTile4_7_Click);
            // 
            // pbLandTile10_5
            // 
            this.pbLandTile10_5.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.pbLandTile10_5.Image = global::OrangeCatans.Properties.Resources.baseLand;
            this.pbLandTile10_5.Location = new System.Drawing.Point(318, 275);
            this.pbLandTile10_5.Name = "pbLandTile10_5";
            this.pbLandTile10_5.Size = new System.Drawing.Size(150, 171);
            this.pbLandTile10_5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbLandTile10_5.TabIndex = 8;
            this.pbLandTile10_5.TabStop = false;
            this.pbLandTile10_5.Tag = "land";
            this.pbLandTile10_5.Click += new System.EventHandler(this.pbLandTile10_5_Click);
            // 
            // pbLandTile2_5
            // 
            this.pbLandTile2_5.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.pbLandTile2_5.Image = global::OrangeCatans.Properties.Resources.baseLand;
            this.pbLandTile2_5.Location = new System.Drawing.Point(6, 275);
            this.pbLandTile2_5.Name = "pbLandTile2_5";
            this.pbLandTile2_5.Size = new System.Drawing.Size(150, 171);
            this.pbLandTile2_5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbLandTile2_5.TabIndex = 7;
            this.pbLandTile2_5.TabStop = false;
            this.pbLandTile2_5.Tag = "land";
            this.pbLandTile2_5.Click += new System.EventHandler(this.pbLandTile2_5_Click);
            // 
            // pbLandTile6_5
            // 
            this.pbLandTile6_5.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.pbLandTile6_5.Image = global::OrangeCatans.Properties.Resources.baseLand;
            this.pbLandTile6_5.Location = new System.Drawing.Point(162, 275);
            this.pbLandTile6_5.Name = "pbLandTile6_5";
            this.pbLandTile6_5.Size = new System.Drawing.Size(150, 171);
            this.pbLandTile6_5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbLandTile6_5.TabIndex = 6;
            this.pbLandTile6_5.TabStop = false;
            this.pbLandTile6_5.Tag = "land";
            this.pbLandTile6_5.Click += new System.EventHandler(this.pbLandTile6_5_Click);
            // 
            // pbLandTile12_3
            // 
            this.pbLandTile12_3.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.pbLandTile12_3.Image = global::OrangeCatans.Properties.Resources.baseLand;
            this.pbLandTile12_3.Location = new System.Drawing.Point(397, 142);
            this.pbLandTile12_3.Name = "pbLandTile12_3";
            this.pbLandTile12_3.Size = new System.Drawing.Size(150, 171);
            this.pbLandTile12_3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbLandTile12_3.TabIndex = 5;
            this.pbLandTile12_3.TabStop = false;
            this.pbLandTile12_3.Tag = "land";
            this.pbLandTile12_3.Click += new System.EventHandler(this.pbLandTile12_3_Click);
            // 
            // pbLandTile8_3
            // 
            this.pbLandTile8_3.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.pbLandTile8_3.Image = global::OrangeCatans.Properties.Resources.baseLand;
            this.pbLandTile8_3.Location = new System.Drawing.Point(241, 142);
            this.pbLandTile8_3.Name = "pbLandTile8_3";
            this.pbLandTile8_3.Size = new System.Drawing.Size(150, 171);
            this.pbLandTile8_3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbLandTile8_3.TabIndex = 4;
            this.pbLandTile8_3.TabStop = false;
            this.pbLandTile8_3.Tag = "land";
            this.pbLandTile8_3.Click += new System.EventHandler(this.pbLandTile8_3_Click);
            // 
            // pbLandTile4_3
            // 
            this.pbLandTile4_3.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.pbLandTile4_3.Image = global::OrangeCatans.Properties.Resources.baseLand;
            this.pbLandTile4_3.Location = new System.Drawing.Point(85, 142);
            this.pbLandTile4_3.Name = "pbLandTile4_3";
            this.pbLandTile4_3.Size = new System.Drawing.Size(150, 171);
            this.pbLandTile4_3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbLandTile4_3.TabIndex = 3;
            this.pbLandTile4_3.TabStop = false;
            this.pbLandTile4_3.Tag = "land";
            this.pbLandTile4_3.Click += new System.EventHandler(this.pbLandTile4_3_Click);
            // 
            // pbLandTile14_1
            // 
            this.pbLandTile14_1.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.pbLandTile14_1.Image = global::OrangeCatans.Properties.Resources.baseLand;
            this.pbLandTile14_1.Location = new System.Drawing.Point(474, 9);
            this.pbLandTile14_1.Name = "pbLandTile14_1";
            this.pbLandTile14_1.Size = new System.Drawing.Size(150, 171);
            this.pbLandTile14_1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbLandTile14_1.TabIndex = 2;
            this.pbLandTile14_1.TabStop = false;
            this.pbLandTile14_1.Tag = "land";
            this.pbLandTile14_1.Click += new System.EventHandler(this.pbLandTile14_1_Click);
            // 
            // pbLandTile10_1
            // 
            this.pbLandTile10_1.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.pbLandTile10_1.Image = global::OrangeCatans.Properties.Resources.baseLand;
            this.pbLandTile10_1.Location = new System.Drawing.Point(318, 9);
            this.pbLandTile10_1.Name = "pbLandTile10_1";
            this.pbLandTile10_1.Size = new System.Drawing.Size(150, 171);
            this.pbLandTile10_1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbLandTile10_1.TabIndex = 1;
            this.pbLandTile10_1.TabStop = false;
            this.pbLandTile10_1.Tag = "land";
            this.pbLandTile10_1.Click += new System.EventHandler(this.pbLandTile10_1_Click);
            // 
            // pbLandTile6_1
            // 
            this.pbLandTile6_1.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.pbLandTile6_1.Image = global::OrangeCatans.Properties.Resources.baseLand;
            this.pbLandTile6_1.Location = new System.Drawing.Point(162, 9);
            this.pbLandTile6_1.Name = "pbLandTile6_1";
            this.pbLandTile6_1.Size = new System.Drawing.Size(150, 171);
            this.pbLandTile6_1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbLandTile6_1.TabIndex = 0;
            this.pbLandTile6_1.TabStop = false;
            this.pbLandTile6_1.Tag = "land";
            this.pbLandTile6_1.Click += new System.EventHandler(this.pbLandTile6_1_Click);
            // 
            // GameControls
            // 
            this.GameControls.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.GameControls.Controls.Add(this.btnHand);
            this.GameControls.Controls.Add(this.btnEndTurn);
            this.GameControls.Controls.Add(this.btnUpgrade);
            this.GameControls.Controls.Add(this.btnBuyCard);
            this.GameControls.Controls.Add(this.btnBuild);
            this.GameControls.Controls.Add(this.btnTrade);
            this.GameControls.Controls.Add(this.btnRoll);
            this.GameControls.Controls.Add(this.flowLayoutPanel1);
            this.GameControls.Location = new System.Drawing.Point(807, 12);
            this.GameControls.Name = "GameControls";
            this.GameControls.Size = new System.Drawing.Size(211, 262);
            this.GameControls.TabIndex = 9;
            this.GameControls.TabStop = false;
            this.GameControls.Text = "Game Controls";
            this.GameControls.Enter += new System.EventHandler(this.groupBox1_Enter);
            // 
            // btnHand
            // 
            this.btnHand.Location = new System.Drawing.Point(104, 206);
            this.btnHand.Name = "btnHand";
            this.btnHand.Size = new System.Drawing.Size(92, 23);
            this.btnHand.TabIndex = 16;
            this.btnHand.Text = "Hand";
            this.btnHand.UseVisualStyleBackColor = true;
            this.btnHand.Click += new System.EventHandler(this.btnHand_Click);
            // 
            // btnEndTurn
            // 
            this.btnEndTurn.Location = new System.Drawing.Point(6, 235);
            this.btnEndTurn.Name = "btnEndTurn";
            this.btnEndTurn.Size = new System.Drawing.Size(190, 23);
            this.btnEndTurn.TabIndex = 15;
            this.btnEndTurn.Text = "End Turn";
            this.btnEndTurn.UseVisualStyleBackColor = true;
            this.btnEndTurn.Click += new System.EventHandler(this.btnEndTurn_Click);
            // 
            // btnUpgrade
            // 
            this.btnUpgrade.Location = new System.Drawing.Point(6, 206);
            this.btnUpgrade.Name = "btnUpgrade";
            this.btnUpgrade.Size = new System.Drawing.Size(92, 23);
            this.btnUpgrade.TabIndex = 14;
            this.btnUpgrade.Text = "Upgrade";
            this.btnUpgrade.UseVisualStyleBackColor = true;
            this.btnUpgrade.Click += new System.EventHandler(this.btnUpgrade_Click);
            // 
            // btnBuyCard
            // 
            this.btnBuyCard.Location = new System.Drawing.Point(104, 177);
            this.btnBuyCard.Name = "btnBuyCard";
            this.btnBuyCard.Size = new System.Drawing.Size(92, 23);
            this.btnBuyCard.TabIndex = 13;
            this.btnBuyCard.Text = "Buy Card";
            this.btnBuyCard.UseVisualStyleBackColor = true;
            this.btnBuyCard.Click += new System.EventHandler(this.btnBuyCard_Click);
            // 
            // btnBuild
            // 
            this.btnBuild.Location = new System.Drawing.Point(6, 177);
            this.btnBuild.Name = "btnBuild";
            this.btnBuild.Size = new System.Drawing.Size(92, 23);
            this.btnBuild.TabIndex = 12;
            this.btnBuild.Text = "Build";
            this.btnBuild.UseVisualStyleBackColor = true;
            this.btnBuild.Click += new System.EventHandler(this.btnBuild_Click);
            // 
            // btnTrade
            // 
            this.btnTrade.Location = new System.Drawing.Point(104, 148);
            this.btnTrade.Name = "btnTrade";
            this.btnTrade.Size = new System.Drawing.Size(92, 23);
            this.btnTrade.TabIndex = 11;
            this.btnTrade.Text = "Trade";
            this.btnTrade.UseVisualStyleBackColor = true;
            this.btnTrade.Click += new System.EventHandler(this.btnTrade_Click);
            // 
            // btnRoll
            // 
            this.btnRoll.Location = new System.Drawing.Point(6, 148);
            this.btnRoll.Name = "btnRoll";
            this.btnRoll.Size = new System.Drawing.Size(92, 23);
            this.btnRoll.TabIndex = 10;
            this.btnRoll.Text = "Roll";
            this.btnRoll.UseVisualStyleBackColor = true;
            this.btnRoll.Click += new System.EventHandler(this.btnRoll_Click);
            // 
            // flowLayoutPanel1
            // 
            this.flowLayoutPanel1.Controls.Add(this.btnPlayer1);
            this.flowLayoutPanel1.Controls.Add(this.btnPlayer2);
            this.flowLayoutPanel1.Controls.Add(this.btnPlayer3);
            this.flowLayoutPanel1.Controls.Add(this.btnPlayer4);
            this.flowLayoutPanel1.Location = new System.Drawing.Point(6, 19);
            this.flowLayoutPanel1.Name = "flowLayoutPanel1";
            this.flowLayoutPanel1.Size = new System.Drawing.Size(200, 123);
            this.flowLayoutPanel1.TabIndex = 9;
            this.flowLayoutPanel1.Paint += new System.Windows.Forms.PaintEventHandler(this.flowLayoutPanel1_Paint);
            // 
            // btnPlayer1
            // 
            this.btnPlayer1.Location = new System.Drawing.Point(3, 3);
            this.btnPlayer1.Name = "btnPlayer1";
            this.btnPlayer1.Size = new System.Drawing.Size(190, 23);
            this.btnPlayer1.TabIndex = 0;
            this.btnPlayer1.Text = "Player 1";
            this.btnPlayer1.UseVisualStyleBackColor = true;
            this.btnPlayer1.Click += new System.EventHandler(this.btnPlayer1_Click);
            // 
            // btnPlayer2
            // 
            this.btnPlayer2.Location = new System.Drawing.Point(3, 32);
            this.btnPlayer2.Name = "btnPlayer2";
            this.btnPlayer2.Size = new System.Drawing.Size(190, 23);
            this.btnPlayer2.TabIndex = 1;
            this.btnPlayer2.Text = "Player 2";
            this.btnPlayer2.UseVisualStyleBackColor = true;
            this.btnPlayer2.Click += new System.EventHandler(this.btnPlayer2_Click);
            // 
            // btnPlayer3
            // 
            this.btnPlayer3.Location = new System.Drawing.Point(3, 61);
            this.btnPlayer3.Name = "btnPlayer3";
            this.btnPlayer3.Size = new System.Drawing.Size(190, 23);
            this.btnPlayer3.TabIndex = 2;
            this.btnPlayer3.Text = "Player 3";
            this.btnPlayer3.UseVisualStyleBackColor = true;
            this.btnPlayer3.Click += new System.EventHandler(this.btnPlayer3_Click);
            // 
            // btnPlayer4
            // 
            this.btnPlayer4.Location = new System.Drawing.Point(3, 90);
            this.btnPlayer4.Name = "btnPlayer4";
            this.btnPlayer4.Size = new System.Drawing.Size(190, 23);
            this.btnPlayer4.TabIndex = 3;
            this.btnPlayer4.Text = "Player 4";
            this.btnPlayer4.UseVisualStyleBackColor = true;
            this.btnPlayer4.Click += new System.EventHandler(this.btnPlayer4_Click);
            // 
            // tbOutputBox
            // 
            this.tbOutputBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tbOutputBox.Location = new System.Drawing.Point(807, 280);
            this.tbOutputBox.Multiline = true;
            this.tbOutputBox.Name = "tbOutputBox";
            this.tbOutputBox.ReadOnly = true;
            this.tbOutputBox.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.tbOutputBox.Size = new System.Drawing.Size(211, 199);
            this.tbOutputBox.TabIndex = 10;
            this.tbOutputBox.Text = "Test\r\nTest\r\nOut";
            this.tbOutputBox.WordWrap = false;
            // 
            // tbPlayerStringInput
            // 
            this.tbPlayerStringInput.Location = new System.Drawing.Point(807, 485);
            this.tbPlayerStringInput.Name = "tbPlayerStringInput";
            this.tbPlayerStringInput.Size = new System.Drawing.Size(211, 20);
            this.tbPlayerStringInput.TabIndex = 11;
            // 
            // btnNewGame
            // 
            this.btnNewGame.Location = new System.Drawing.Point(943, 511);
            this.btnNewGame.Name = "btnNewGame";
            this.btnNewGame.Size = new System.Drawing.Size(75, 23);
            this.btnNewGame.TabIndex = 12;
            this.btnNewGame.Text = "New Game";
            this.btnNewGame.UseVisualStyleBackColor = true;
            this.btnNewGame.Click += new System.EventHandler(this.button1_Click);
            // 
            // Catan
            // 
            this.AllowDrop = global::OrangeCatans.Properties.Settings.Default.Check;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(1030, 741);
            this.Controls.Add(this.btnNewGame);
            this.Controls.Add(this.tbPlayerStringInput);
            this.Controls.Add(this.tbOutputBox);
            this.Controls.Add(this.GameControls);
            this.Controls.Add(this.MapBox);
            this.Name = "Catan";
            this.TransparencyKey = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.MapBox.ResumeLayout(false);
            this.MapBox.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbSettle0_4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbSettle0_6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbSettle14_10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbSettle6_10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbSettle10_10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbSettle16_10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbSettle12_10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbSettle8_10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbSettle4_10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbSettle8_8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbSettle12_8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbSettle16_8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbSettle18_8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbSettle14_8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbSettle10_8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbSettle6_8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbSettle2_8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbSettle4_8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbSettle20_6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbSettle18_6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbSettle16_6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbSettle14_6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbSettle12_6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbSettle10_6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbSettle8_6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbSettle6_6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbSettle2_6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbSettle4_6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbSettle20_4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbSettle18_4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbSettle16_4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbSettle14_4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbSettle12_4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbSettle10_4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbSettle4_4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbSettle8_4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbSettle6_4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbSettle2_4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbSettle2_2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbSettle18_2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbSettle12_2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbSettle16_2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbSettle14_2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbSettle10_2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbSettle8_2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbSettle6_2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbSettle4_2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbSettle16_0)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbSettle12_0)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbSettle8_0)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbSettle4_0)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbSettle14_0)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbSettle10_0)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbSettle6_0)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbRoad11_6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbRoad17_8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbRoad15_10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbRoad13_10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbRoad11_10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbRoad9_10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbRoad7_10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbRoad5_10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbRoad16_9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbRoad12_9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbRoad8_9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbRoad4_9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbRoad15_8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbRoad13_8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbRoad11_8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbRoad9_8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbRoad7_8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbRoad5_8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbRoad18_7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbRoad3_8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbRoad10_7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbRoad6_7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbRoad2_7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbRoad19_6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbRoad17_6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbRoad15_6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbRoad13_6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbRoad14_7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbRoad19_4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbRoad20_5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbRoad16_5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbRoad12_5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbRoad9_6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbRoad8_5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbRoad7_6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbRoad5_6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbRoad3_6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbRoad1_6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbRoad4_5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbRoad0_5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbRoad1_4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbRoad13_4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbRoad15_4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbRoad17_4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbRoad17_2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbRoad18_3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbRoad14_3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbRoad11_4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbRoad7_4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbRoad9_4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbRoad10_3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbRoad2_3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbRoad3_4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbRoad5_4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbRoad6_3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbRoad3_2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbRoad13_0)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbRoad13_2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbRoad15_2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbRoad16_1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbRoad15_0)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbRoad9_0)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbRoad9_2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbRoad11_2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbRoad12_1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbRoad11_0)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbRoad5_0)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbRoad4_1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbRoad5_2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbRoad7_2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbRoad8_1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbLandTile14_9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbRoad7_0)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbLandTile10_9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbLandTile16_7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbLandTile12_7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbLandTile18_5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbLandTile14_5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbLandTile16_3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbLandTile6_9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbLandTile8_7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbLandTile4_7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbLandTile10_5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbLandTile2_5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbLandTile6_5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbLandTile12_3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbLandTile8_3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbLandTile4_3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbLandTile14_1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbLandTile10_1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbLandTile6_1)).EndInit();
            this.GameControls.ResumeLayout(false);
            this.flowLayoutPanel1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.PictureBox pbLandTile10_1;
        private System.Windows.Forms.PictureBox pbLandTile14_1;
        private System.Windows.Forms.PictureBox pbLandTile4_3;
        private System.Windows.Forms.PictureBox pbLandTile8_3;
        private System.Windows.Forms.PictureBox pbLandTile12_3;
        private System.Windows.Forms.PictureBox pbLandTile6_5;
        private System.Windows.Forms.PictureBox pbLandTile2_5;
        private System.Windows.Forms.PictureBox pbLandTile10_5;
        private System.Windows.Forms.PictureBox pbLandTile4_7;
        private System.Windows.Forms.PictureBox pbLandTile8_7;
        private System.Windows.Forms.PictureBox pbLandTile12_7;
        private System.Windows.Forms.PictureBox pbLandTile6_9;
        private System.Windows.Forms.PictureBox pbLandTile14_5;
        private System.Windows.Forms.PictureBox pbLandTile18_5;
        private System.Windows.Forms.PictureBox pbLandTile16_3;
        private System.Windows.Forms.PictureBox pbLandTile16_7;
        private System.Windows.Forms.GroupBox MapBox;
        private System.Windows.Forms.PictureBox pbLandTile10_9;
        private System.Windows.Forms.PictureBox pbRoad7_0;
        private System.Windows.Forms.GroupBox GameControls;
        private System.Windows.Forms.Button btnHand;
        private System.Windows.Forms.Button btnEndTurn;
        private System.Windows.Forms.Button btnUpgrade;
        private System.Windows.Forms.Button btnBuyCard;
        private System.Windows.Forms.Button btnBuild;
        private System.Windows.Forms.Button btnTrade;
        private System.Windows.Forms.Button btnRoll;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel1;
        private System.Windows.Forms.Button btnPlayer1;
        private System.Windows.Forms.Button btnPlayer2;
        private System.Windows.Forms.Button btnPlayer3;
        private System.Windows.Forms.Button btnPlayer4;
        private System.Windows.Forms.PictureBox pbLandTile6_1;
        private System.Windows.Forms.PictureBox pbLandTile14_9;
        private System.Windows.Forms.PictureBox pbRoad13_0;
        private System.Windows.Forms.PictureBox pbRoad13_2;
        private System.Windows.Forms.PictureBox pbRoad15_2;
        private System.Windows.Forms.PictureBox pbRoad16_1;
        private System.Windows.Forms.PictureBox pbRoad15_0;
        private System.Windows.Forms.PictureBox pbRoad9_0;
        private System.Windows.Forms.PictureBox pbRoad9_2;
        private System.Windows.Forms.PictureBox pbRoad11_2;
        private System.Windows.Forms.PictureBox pbRoad12_1;
        private System.Windows.Forms.PictureBox pbRoad11_0;
        private System.Windows.Forms.PictureBox pbRoad5_0;
        private System.Windows.Forms.PictureBox pbRoad4_1;
        private System.Windows.Forms.PictureBox pbRoad5_2;
        private System.Windows.Forms.PictureBox pbRoad7_2;
        private System.Windows.Forms.PictureBox pbRoad8_1;
        private System.Windows.Forms.PictureBox pbRoad13_4;
        private System.Windows.Forms.PictureBox pbRoad15_4;
        private System.Windows.Forms.PictureBox pbRoad17_4;
        private System.Windows.Forms.PictureBox pbRoad17_2;
        private System.Windows.Forms.PictureBox pbRoad18_3;
        private System.Windows.Forms.PictureBox pbRoad14_3;
        private System.Windows.Forms.PictureBox pbRoad11_4;
        private System.Windows.Forms.PictureBox pbRoad7_4;
        private System.Windows.Forms.PictureBox pbRoad9_4;
        private System.Windows.Forms.PictureBox pbRoad10_3;
        private System.Windows.Forms.PictureBox pbRoad2_3;
        private System.Windows.Forms.PictureBox pbRoad3_4;
        private System.Windows.Forms.PictureBox pbRoad5_4;
        private System.Windows.Forms.PictureBox pbRoad6_3;
        private System.Windows.Forms.PictureBox pbRoad3_2;
        private System.Windows.Forms.TextBox tbOutputBox;
        private System.Windows.Forms.TextBox tbPlayerStringInput;
        private System.Windows.Forms.Button btnNewGame;
        private System.Windows.Forms.PictureBox pbRoad19_6;
        private System.Windows.Forms.PictureBox pbRoad17_6;
        private System.Windows.Forms.PictureBox pbRoad15_6;
        private System.Windows.Forms.PictureBox pbRoad13_6;
        private System.Windows.Forms.PictureBox pbRoad14_7;
        private System.Windows.Forms.PictureBox pbRoad19_4;
        private System.Windows.Forms.PictureBox pbRoad20_5;
        private System.Windows.Forms.PictureBox pbRoad16_5;
        private System.Windows.Forms.PictureBox pbRoad12_5;
        private System.Windows.Forms.PictureBox pbRoad9_6;
        private System.Windows.Forms.PictureBox pbRoad8_5;
        private System.Windows.Forms.PictureBox pbRoad7_6;
        private System.Windows.Forms.PictureBox pbRoad5_6;
        private System.Windows.Forms.PictureBox pbRoad3_6;
        private System.Windows.Forms.PictureBox pbRoad1_6;
        private System.Windows.Forms.PictureBox pbRoad4_5;
        private System.Windows.Forms.PictureBox pbRoad0_5;
        private System.Windows.Forms.PictureBox pbRoad1_4;
        private System.Windows.Forms.PictureBox pbRoad11_6;
        private System.Windows.Forms.PictureBox pbRoad17_8;
        private System.Windows.Forms.PictureBox pbRoad15_10;
        private System.Windows.Forms.PictureBox pbRoad13_10;
        private System.Windows.Forms.PictureBox pbRoad11_10;
        private System.Windows.Forms.PictureBox pbRoad9_10;
        private System.Windows.Forms.PictureBox pbRoad7_10;
        private System.Windows.Forms.PictureBox pbRoad5_10;
        private System.Windows.Forms.PictureBox pbRoad16_9;
        private System.Windows.Forms.PictureBox pbRoad12_9;
        private System.Windows.Forms.PictureBox pbRoad8_9;
        private System.Windows.Forms.PictureBox pbRoad4_9;
        private System.Windows.Forms.PictureBox pbRoad15_8;
        private System.Windows.Forms.PictureBox pbRoad13_8;
        private System.Windows.Forms.PictureBox pbRoad11_8;
        private System.Windows.Forms.PictureBox pbRoad9_8;
        private System.Windows.Forms.PictureBox pbRoad7_8;
        private System.Windows.Forms.PictureBox pbRoad5_8;
        private System.Windows.Forms.PictureBox pbRoad18_7;
        private System.Windows.Forms.PictureBox pbRoad3_8;
        private System.Windows.Forms.PictureBox pbRoad10_7;
        private System.Windows.Forms.PictureBox pbRoad6_7;
        private System.Windows.Forms.PictureBox pbRoad2_7;
        private System.Windows.Forms.PictureBox pbSettle14_10;
        private System.Windows.Forms.PictureBox pbSettle6_10;
        private System.Windows.Forms.PictureBox pbSettle10_10;
        private System.Windows.Forms.PictureBox pbSettle16_10;
        private System.Windows.Forms.PictureBox pbSettle12_10;
        private System.Windows.Forms.PictureBox pbSettle8_10;
        private System.Windows.Forms.PictureBox pbSettle4_10;
        private System.Windows.Forms.PictureBox pbSettle8_8;
        private System.Windows.Forms.PictureBox pbSettle12_8;
        private System.Windows.Forms.PictureBox pbSettle16_8;
        private System.Windows.Forms.PictureBox pbSettle18_8;
        private System.Windows.Forms.PictureBox pbSettle14_8;
        private System.Windows.Forms.PictureBox pbSettle10_8;
        private System.Windows.Forms.PictureBox pbSettle6_8;
        private System.Windows.Forms.PictureBox pbSettle2_8;
        private System.Windows.Forms.PictureBox pbSettle4_8;
        private System.Windows.Forms.PictureBox pbSettle20_6;
        private System.Windows.Forms.PictureBox pbSettle18_6;
        private System.Windows.Forms.PictureBox pbSettle16_6;
        private System.Windows.Forms.PictureBox pbSettle14_6;
        private System.Windows.Forms.PictureBox pbSettle12_6;
        private System.Windows.Forms.PictureBox pbSettle10_6;
        private System.Windows.Forms.PictureBox pbSettle8_6;
        private System.Windows.Forms.PictureBox pbSettle6_6;
        private System.Windows.Forms.PictureBox pbSettle2_6;
        private System.Windows.Forms.PictureBox pbSettle4_6;
        private System.Windows.Forms.PictureBox pbSettle0_6;
        private System.Windows.Forms.PictureBox pbSettle0_4;
        private System.Windows.Forms.PictureBox pbSettle20_4;
        private System.Windows.Forms.PictureBox pbSettle18_4;
        private System.Windows.Forms.PictureBox pbSettle16_4;
        private System.Windows.Forms.PictureBox pbSettle14_4;
        private System.Windows.Forms.PictureBox pbSettle12_4;
        private System.Windows.Forms.PictureBox pbSettle10_4;
        private System.Windows.Forms.PictureBox pbSettle4_4;
        private System.Windows.Forms.PictureBox pbSettle8_4;
        private System.Windows.Forms.PictureBox pbSettle6_4;
        private System.Windows.Forms.PictureBox pbSettle2_4;
        private System.Windows.Forms.PictureBox pbSettle2_2;
        private System.Windows.Forms.PictureBox pbSettle18_2;
        private System.Windows.Forms.PictureBox pbSettle12_2;
        private System.Windows.Forms.PictureBox pbSettle16_2;
        private System.Windows.Forms.PictureBox pbSettle14_2;
        private System.Windows.Forms.PictureBox pbSettle10_2;
        private System.Windows.Forms.PictureBox pbSettle8_2;
        private System.Windows.Forms.PictureBox pbSettle6_2;
        private System.Windows.Forms.PictureBox pbSettle4_2;
        private System.Windows.Forms.PictureBox pbSettle16_0;
        private System.Windows.Forms.PictureBox pbSettle12_0;
        private System.Windows.Forms.PictureBox pbSettle8_0;
        private System.Windows.Forms.PictureBox pbSettle14_0;
        private System.Windows.Forms.PictureBox pbSettle10_0;
        private System.Windows.Forms.PictureBox pbSettle6_0;
        private System.Windows.Forms.PictureBox pbSettle4_0;
        private System.Windows.Forms.Label lbl6_1;
        private System.Windows.Forms.Label lbl14_9;
        private System.Windows.Forms.Label lbl10_9;
        private System.Windows.Forms.Label lbl6_9;
        private System.Windows.Forms.Label lbl16_7;
        private System.Windows.Forms.Label lbl12_7;
        private System.Windows.Forms.Label lbl8_7;
        private System.Windows.Forms.Label lbl4_7;
        private System.Windows.Forms.Label lbl18_5;
        private System.Windows.Forms.Label lbl14_5;
        private System.Windows.Forms.Label lbl10_5;
        private System.Windows.Forms.Label lbl6_5;
        private System.Windows.Forms.Label lbl2_5;
        private System.Windows.Forms.Label lbl16_3;
        private System.Windows.Forms.Label lbl12_3;
        private System.Windows.Forms.Label lbl8_3;
        private System.Windows.Forms.Label lbl4_3;
        private System.Windows.Forms.Label lbl14_1;
        private System.Windows.Forms.Label lbl10_1;
    }
    
    
}

